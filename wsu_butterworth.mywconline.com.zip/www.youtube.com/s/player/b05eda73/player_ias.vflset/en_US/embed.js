(function(g) {
    var window = this;
    /*
     SPDX-License-Identifier: Apache-2.0
    */
    /*

     Copyright Google LLC All Rights Reserved.

     Use of this source code is governed by an MIT-style license that can be
     found in the LICENSE file at https://angular.io/license
    */
    /*

     Copyright 2017 Google LLC
     SPDX-License-Identifier: BSD-3-Clause
    */
    'use strict';
    var Srb = function(a) {
            a.mutedAutoplay = !1;
            a.endSeconds = NaN;
            a.limitedPlaybackDurationInSeconds = NaN;
            g.JS(a)
        },
        Trb = function() {
            return {
                I: "svg",
                X: {
                    height: "100%",
                    version: "1.1",
                    viewBox: "0 0 110 26",
                    width: "100%"
                },
                V: [{
                    I: "path",
                    Ec: !0,
                    S: "ytp-svg-fill",
                    X: {
                        d: "M 16.68,.99 C 13.55,1.03 7.02,1.16 4.99,1.68 c -1.49,.4 -2.59,1.6 -2.99,3 -0.69,2.7 -0.68,8.31 -0.68,8.31 0,0 -0.01,5.61 .68,8.31 .39,1.5 1.59,2.6 2.99,3 2.69,.7 13.40,.68 13.40,.68 0,0 10.70,.01 13.40,-0.68 1.5,-0.4 2.59,-1.6 2.99,-3 .69,-2.7 .68,-8.31 .68,-8.31 0,0 .11,-5.61 -0.68,-8.31 -0.4,-1.5 -1.59,-2.6 -2.99,-3 C 29.11,.98 18.40,.99 18.40,.99 c 0,0 -0.67,-0.01 -1.71,0 z m 72.21,.90 0,21.28 2.78,0 .31,-1.37 .09,0 c .3,.5 .71,.88 1.21,1.18 .5,.3 1.08,.40 1.68,.40 1.1,0 1.99,-0.49 2.49,-1.59 .5,-1.1 .81,-2.70 .81,-4.90 l 0,-2.40 c 0,-1.6 -0.11,-2.90 -0.31,-3.90 -0.2,-0.89 -0.5,-1.59 -1,-2.09 -0.5,-0.4 -1.10,-0.59 -1.90,-0.59 -0.59,0 -1.18,.19 -1.68,.49 -0.49,.3 -1.01,.80 -1.21,1.40 l 0,-7.90 -3.28,0 z m -49.99,.78 3.90,13.90 .18,6.71 3.31,0 0,-6.71 3.87,-13.90 -3.37,0 -1.40,6.31 c -0.4,1.89 -0.71,3.19 -0.81,3.99 l -0.09,0 c -0.2,-1.1 -0.51,-2.4 -0.81,-3.99 l -1.37,-6.31 -3.40,0 z m 29.59,0 0,2.71 3.40,0 0,17.90 3.28,0 0,-17.90 3.40,0 c 0,0 .00,-2.71 -0.09,-2.71 l -9.99,0 z m -53.49,5.12 8.90,5.18 -8.90,5.09 0,-10.28 z m 89.40,.09 c -1.7,0 -2.89,.59 -3.59,1.59 -0.69,.99 -0.99,2.60 -0.99,4.90 l 0,2.59 c 0,2.2 .30,3.90 .99,4.90 .7,1.1 1.8,1.59 3.5,1.59 1.4,0 2.38,-0.3 3.18,-1 .7,-0.7 1.09,-1.69 1.09,-3.09 l 0,-0.5 -2.90,-0.21 c 0,1 -0.08,1.6 -0.28,2 -0.1,.4 -0.5,.62 -1,.62 -0.3,0 -0.61,-0.11 -0.81,-0.31 -0.2,-0.3 -0.30,-0.59 -0.40,-1.09 -0.1,-0.5 -0.09,-1.21 -0.09,-2.21 l 0,-0.78 5.71,-0.09 0,-2.62 c 0,-1.6 -0.10,-2.78 -0.40,-3.68 -0.2,-0.89 -0.71,-1.59 -1.31,-1.99 -0.7,-0.4 -1.48,-0.59 -2.68,-0.59 z m -50.49,.09 c -1.09,0 -2.01,.18 -2.71,.68 -0.7,.4 -1.2,1.12 -1.49,2.12 -0.3,1 -0.5,2.27 -0.5,3.87 l 0,2.21 c 0,1.5 .10,2.78 .40,3.78 .2,.9 .70,1.62 1.40,2.12 .69,.5 1.71,.68 2.81,.78 1.19,0 2.08,-0.28 2.78,-0.68 .69,-0.4 1.09,-1.09 1.49,-2.09 .39,-1 .49,-2.30 .49,-3.90 l 0,-2.21 c 0,-1.6 -0.2,-2.87 -0.49,-3.87 -0.3,-0.89 -0.8,-1.62 -1.49,-2.12 -0.7,-0.5 -1.58,-0.68 -2.68,-0.68 z m 12.18,.09 0,11.90 c -0.1,.3 -0.29,.48 -0.59,.68 -0.2,.2 -0.51,.31 -0.81,.31 -0.3,0 -0.58,-0.10 -0.68,-0.40 -0.1,-0.3 -0.18,-0.70 -0.18,-1.40 l 0,-10.99 -3.40,0 0,11.21 c 0,1.4 .18,2.39 .68,3.09 .49,.7 1.21,1 2.21,1 1.4,0 2.48,-0.69 3.18,-2.09 l .09,0 .31,1.78 2.59,0 0,-14.99 c 0,0 -3.40,.00 -3.40,-0.09 z m 17.31,0 0,11.90 c -0.1,.3 -0.29,.48 -0.59,.68 -0.2,.2 -0.51,.31 -0.81,.31 -0.3,0 -0.58,-0.10 -0.68,-0.40 -0.1,-0.3 -0.21,-0.70 -0.21,-1.40 l 0,-10.99 -3.40,0 0,11.21 c 0,1.4 .21,2.39 .71,3.09 .5,.7 1.18,1 2.18,1 1.39,0 2.51,-0.69 3.21,-2.09 l .09,0 .28,1.78 2.62,0 0,-14.99 c 0,0 -3.40,.00 -3.40,-0.09 z m 20.90,2.09 c .4,0 .58,.11 .78,.31 .2,.3 .30,.59 .40,1.09 .1,.5 .09,1.21 .09,2.21 l 0,1.09 -2.5,0 0,-1.09 c 0,-1 -0.00,-1.71 .09,-2.21 0,-0.4 .11,-0.8 .31,-1 .2,-0.3 .51,-0.40 .81,-0.40 z m -50.49,.12 c .5,0 .8,.18 1,.68 .19,.5 .28,1.30 .28,2.40 l 0,4.68 c 0,1.1 -0.08,1.90 -0.28,2.40 -0.2,.5 -0.5,.68 -1,.68 -0.5,0 -0.79,-0.18 -0.99,-0.68 -0.2,-0.5 -0.31,-1.30 -0.31,-2.40 l 0,-4.68 c 0,-1.1 .11,-1.90 .31,-2.40 .2,-0.5 .49,-0.68 .99,-0.68 z m 39.68,.09 c .3,0 .61,.10 .81,.40 .2,.3 .27,.67 .37,1.37 .1,.6 .12,1.51 .12,2.71 l .09,1.90 c 0,1.1 .00,1.99 -0.09,2.59 -0.1,.6 -0.19,1.08 -0.49,1.28 -0.2,.3 -0.50,.40 -0.90,.40 -0.3,0 -0.51,-0.08 -0.81,-0.18 -0.2,-0.1 -0.39,-0.29 -0.59,-0.59 l 0,-8.5 c .1,-0.4 .29,-0.7 .59,-1 .3,-0.3 .60,-0.40 .90,-0.40 z"
                    }
                }]
            }
        },
        Urb = function() {
            return {
                I: "svg",
                X: {
                    fill: "none",
                    height: "51",
                    viewBox: "0 0 143 51",
                    width: "143"
                },
                V: [{
                    I: "path",
                    X: {
                        d: "M58.37 41.39H62.79V27.23C62.79 23.03 62.69 18.69 62.43 13.59H62.93L63.69 16.89L68.67 41.39H73.17L78.07 16.89L78.89 13.59H79.37C79.15 18.45 79.03 22.89 79.03 27.23V41.39H83.45V8.79H75.95L73.41 20.81C72.35 25.85 71.51 32.01 71.01 35.19H70.73C70.33 31.95 69.49 25.81 68.41 20.85L65.81 8.79H58.37V41.39Z",
                        fill: "white"
                    }
                }, {
                    I: "path",
                    X: {
                        d: "M91.45 41.73C93.91 41.73 95.83 40.59 97.17 38.13H97.35L97.69 41.39H101.43V17.73H96.47V36.61C95.91 37.67 94.81 38.29 93.73 38.29C92.33 38.29 91.89 37.17 91.89 35.13V17.73H86.93V35.43C86.93 39.49 88.19 41.73 91.45 41.73Z",
                        fill: "white"
                    }
                }, {
                    I: "path",
                    X: {
                        d: "M110.79 41.89C115.15 41.89 117.75 39.83 117.75 35.65C117.75 31.79 115.93 30.39 111.85 27.47C109.67 25.91 108.39 25.09 108.39 22.95C108.39 21.47 109.27 20.61 110.89 20.61C112.69 20.61 113.33 21.81 113.33 25.29L117.45 25.07C117.77 19.57 115.71 17.23 110.97 17.23C106.57 17.23 104.17 19.27 104.17 23.45C104.17 27.25 105.97 28.83 108.93 31.03C111.89 33.23 113.55 34.53 113.55 36.23C113.55 37.75 112.51 38.61 111.01 38.61C109.13 38.61 108.11 36.97 108.29 34.41L104.21 34.49C103.51 39.25 105.89 41.89 110.79 41.89Z",
                        fill: "white"
                    }
                }, {
                    I: "path",
                    X: {
                        d: "M122.5 14.59C124.22 14.59 125.04 13.99 125.04 11.59C125.04 9.33 124.16 8.65 122.5 8.65C120.84 8.65 119.94 9.27 119.94 11.59C119.94 13.99 120.82 14.59 122.5 14.59ZM120.2 41.39H125V17.73H120.2V41.39Z",
                        fill: "white"
                    }
                }, {
                    I: "path",
                    X: {
                        d: "M134.95 41.79C137.31 41.79 138.63 41.49 139.71 40.47C141.31 39.01 141.97 36.63 141.85 33.11L137.41 32.87C137.41 36.87 136.81 38.45 135.03 38.45C133.13 38.45 132.77 36.45 132.77 31.97V27.21C132.77 22.41 133.23 20.51 135.07 20.51C136.67 20.51 137.29 22.01 137.29 26.47L141.65 26.15C141.97 22.93 141.59 20.29 140.09 18.83C139.01 17.77 137.37 17.29 135.15 17.29C129.65 17.29 127.75 20.73 127.75 28.03V31.17C127.75 38.47 129.23 41.79 134.95 41.79Z",
                        fill: "white"
                    }
                }, {
                    I: "path",
                    X: {
                        "clip-rule": "evenodd",
                        d: "M24.99 49C29.74 49.00 34.38 47.59 38.32 44.95C42.27 42.32 45.35 38.57 47.17 34.18C48.98 29.80 49.46 24.97 48.53 20.32C47.61 15.66 45.32 11.38 41.97 8.03C38.61 4.67 34.33 2.38 29.68 1.46C25.02 .53 20.20 1.01 15.81 2.82C11.43 4.64 7.68 7.71 5.04 11.66C2.40 15.61 1 20.25 1 25C0.99 28.15 1.61 31.27 2.82 34.18C4.03 37.09 5.79 39.74 8.02 41.97C10.25 44.19 12.89 45.96 15.81 47.17C18.72 48.37 21.84 49 24.99 49ZM24.99 12.36C27.49 12.36 29.94 13.10 32.02 14.48C34.10 15.87 35.72 17.84 36.68 20.15C37.64 22.46 37.89 25.01 37.41 27.46C36.92 29.91 35.72 32.17 33.95 33.94C32.18 35.70 29.93 36.91 27.48 37.40C25.02 37.89 22.48 37.64 20.17 36.68C17.86 35.72 15.88 34.10 14.50 32.02C13.11 29.94 12.37 27.50 12.37 25C12.37 21.65 13.70 18.44 16.07 16.07C18.43 13.70 21.64 12.37 24.99 12.36ZM24.99 10.43C22.11 10.43 19.29 11.28 16.89 12.88C14.50 14.48 12.63 16.76 11.53 19.42C10.42 22.09 10.13 25.02 10.70 27.85C11.26 30.67 12.65 33.27 14.69 35.31C16.73 37.35 19.32 38.73 22.15 39.30C24.98 39.86 27.91 39.57 30.57 38.46C33.23 37.36 35.51 35.49 37.11 33.09C38.71 30.70 39.57 27.88 39.56 25C39.56 23.08 39.19 21.19 38.46 19.42C37.72 17.65 36.65 16.04 35.30 14.69C33.94 13.34 32.34 12.27 30.57 11.53C28.80 10.80 26.90 10.43 24.99 10.43ZM32.63 24.99L20.36 32.09V17.91L32.63 24.99Z",
                        fill: "white",
                        "fill-rule": "evenodd"
                    }
                }]
            }
        },
        Vrb = function() {},
        c5 = function(a, b) {
            for (; a.length > b;) a.pop()
        },
        Wrb = function(a) {
            a = Array(a);
            c5(a, 0);
            return a
        },
        Xrb = function(a, b, c) {
            if (null == c) a.removeAttribute(b);
            else {
                var d = 0 === b.lastIndexOf("xml:", 0) ? "http://www.w3.org/XML/1998/namespace" : 0 === b.lastIndexOf("xlink:", 0) ? "http://www.w3.org/1999/xlink" : null;
                d ? a.setAttributeNS(d, b, c) : a.setAttribute(b, c)
            }
        },
        Zrb = function(a, b, c) {
            a = a.style;
            if ("string" === typeof c) a.cssText = c;
            else {
                a.cssText = "";
                for (var d in c)
                    if (Yrb.call(c, d)) {
                        b = a;
                        var e = d,
                            f = c[d];
                        0 <= e.indexOf("-") ? b.setProperty(e, f) : b[e] = f
                    }
            }
        },
        $rb = function(a, b, c) {
            var d = typeof c;
            "object" === d || "function" === d ? a[b] = c : Xrb(a, b, c)
        },
        asb = function() {
            var a = new Vrb;
            a.__default = $rb;
            a.style = Zrb;
            return a
        },
        bsb = function(a, b, c, d) {
            (d[b] || d.__default)(a, b, c)
        },
        csb = function(a) {
            this.created = [];
            this.j = [];
            this.node = a
        },
        dsb = function(a, b) {
            this.j = null;
            this.B = a;
            this.key = b;
            this.text = void 0
        },
        esb = function(a, b, c) {
            b = new dsb(b, c);
            return a.__incrementalDOMData = b
        },
        d5 = function(a, b) {
            if (a.__incrementalDOMData) return a.__incrementalDOMData;
            var c = 1 === a.nodeType ? a.localName : a.nodeName,
                d = 1 === a.nodeType ? a.getAttribute("key") : null;
            b = esb(a, c, 1 === a.nodeType ? d || b : null);
            if (1 === a.nodeType && (a = a.attributes, c = a.length)) {
                d = b.j || (b.j = Wrb(2 * c));
                for (var e = 0, f = 0; e < c; e += 1, f += 2) {
                    var h = a[e],
                        l = h.value;
                    d[f] = h.name;
                    d[f + 1] = l
                }
            }
            return b
        },
        fsb = function(a, b, c, d, e) {
            return b == c && d == e
        },
        h5 = function(a) {
            for (var b = e5, c = f5(); c !== a;) {
                var d = c.nextSibling;
                b.removeChild(c);
                g5.j.push(c);
                c = d
            }
        },
        f5 = function() {
            return i5 ? i5.nextSibling : e5.firstChild
        },
        gsb = function(a, b) {
            i5 = f5();
            var c;
            a: {
                if (c = i5) {
                    do {
                        var d = c,
                            e = a,
                            f = b,
                            h = d5(d, f);
                        if (j5(d, e, h.B, f, h.key)) break a
                    } while (b && (c = c.nextSibling))
                }
                c = null
            }
            c || ("#text" === a ? (a = k5.createTextNode(""), esb(a, "#text", null)) : (c = k5, d = e5, "function" === typeof a ? c = new a : c = (d = "svg" === a ? "http://www.w3.org/2000/svg" : "math" === a ? "http://www.w3.org/1998/Math/MathML" : null == d || "foreignObject" === d5(d).B ? null : d.namespaceURI) ? c.createElementNS(d, a) : c.createElement(a), esb(c, a, b), a = c), g5.created.push(a), c = a);
            a = c;
            if (a !== i5) {
                if (0 <= l5.indexOf(a))
                    for (b = e5, c = a.nextSibling,
                        d = i5; null !== d && d !== a;) e = d.nextSibling, b.insertBefore(d, c), d = e;
                else e5.insertBefore(a, i5);
                i5 = a
            }
        },
        hsb = function(a, b) {
            gsb(a, b);
            e5 = i5;
            i5 = null;
            return e5
        },
        jsb = function(a, b) {
            b = void 0 === b ? {} : b;
            var c = void 0 === b.matches ? fsb : b.matches;
            return function(d, e, f) {
                var h = g5,
                    l = k5,
                    m = l5,
                    n = m5,
                    p = i5,
                    q = e5,
                    r = j5;
                k5 = d.ownerDocument;
                g5 = new csb(d);
                j5 = c;
                m5 = [];
                i5 = null;
                var t = e5 = d.parentNode,
                    v, w = isb.call(d);
                if ((v = 11 === w.nodeType || 9 === w.nodeType ? w.activeElement : null) && d.contains(v)) {
                    for (w = []; v !== t;) w.push(v), v = v.parentNode || (t ? v.host : null);
                    t = w
                } else t = [];
                l5 = t;
                try {
                    return a(d, e, f)
                } finally {
                    d = g5, n5 && 0 < d.j.length && n5(d.j), k5 = l, g5 = h, j5 = r, m5 = n, i5 = p, e5 = q, l5 = m
                }
            }
        },
        ksb = function(a, b, c, d) {
            o5.push(bsb);
            o5.push(a);
            o5.push(b);
            o5.push(c);
            o5.push(d)
        },
        lsb = function(a) {
            gsb("#text", null);
            var b = i5;
            var c = d5(b);
            if (c.text !== a) {
                c = c.text = a;
                for (var d = 1; d < arguments.length; d += 1) c = (0, arguments[d])(c);
                b.data !== c && (b.data = c)
            }
        },
        msb = function(a, b) {
            p5.push({
                name: a.Z6 ? a.name + " (" + a.Z6 + ")" : a.name,
                nA: !!a.nA
            });
            a = b();
            p5.pop();
            return a
        },
        q5 = function() {
            var a, b;
            return null != (b = null == (a = p5[p5.length - 1]) ? void 0 : a.nA) ? b : !1
        },
        s5 = function(a, b) {
            b = void 0 === b ? {} : b;
            if (!r5.hea) return a();
            var c = p5.length;
            b.stack && (p5 = [].concat(g.qa(b.stack)));
            try {
                return a()
            } catch (d) {
                throw nsb(d), d;
            } finally {
                a = p5.length - c, 0 < a && p5.splice(-a)
            }
        },
        nsb = function(a) {
            var b = p5;
            0 === b.length || a[osb] || (b = b.slice(-20).reverse().map(function(c) {
                return c.name
            }).join(" > "), b = a.message + "\n\nComponent stack: " + b, a.stack && (a.stack = a.stack.replace(a.message, b)), a.message = b, a[osb] = !0)
        },
        t5 = function(a) {
            this.props = a;
            this.C = !1
        },
        v5 = function(a, b) {
            var c = u5;
            u5 = a;
            try {
                return b()
            } finally {
                u5 = c
            }
        },
        psb = function(a, b) {
            return Object.is(a, b)
        },
        w5 = function(a) {
            var b = qsb;
            qsb = a;
            return b
        },
        rsb = function(a) {
            a.Yl = !0;
            if (void 0 !== a.bk) {
                var b = x5;
                x5 = !0;
                try {
                    for (var c = g.u(a.bk), d = c.next(); !d.done; d = c.next()) {
                        var e = d.value;
                        e.Yl || rsb(e)
                    }
                } finally {
                    x5 = b
                }
            }
            var f;
            null == (f = a.IW) || f.call(a, a)
        },
        ssb = function(a) {
            a && (a.CQ = 0);
            return w5(a)
        },
        vsb = function(a, b) {
            w5(b);
            if (a && void 0 !== a.vk && void 0 !== a.Nr && void 0 !== a.rB) {
                if (tsb(a))
                    for (b = a.CQ; b < a.vk.length; b++) usb(a.vk[b], a.Nr[b]);
                for (; a.vk.length > a.CQ;) a.vk.pop(), a.rB.pop(), a.Nr.pop()
            }
        },
        wsb = function(a) {
            y5(a);
            for (var b = 0; b < a.vk.length; b++) {
                var c = a.vk[b],
                    d = a.rB[b];
                if (d !== c.version) return !0;
                if (!tsb(c) || c.Yl)
                    if (c.Yl || 1 !== c.TY)(c.W_(c) || wsb(c)) && c.X_(c), c.Yl = !1, c.TY = 1;
                if (d !== c.version) return !0
            }
            return !1
        },
        usb = function(a, b) {
            null != a.bk || (a.bk = []);
            null != a.Rw || (a.Rw = []);
            y5(a);
            if (1 === a.bk.length)
                for (var c = 0; c < a.vk.length; c++) usb(a.vk[c], a.Nr[c]);
            c = a.bk.length - 1;
            a.bk[b] = a.bk[c];
            a.Rw[b] = a.Rw[c];
            a.bk.length--;
            a.Rw.length--;
            b < a.bk.length && (c = a.Rw[b], a = a.bk[b], y5(a), a.Nr[c] = b)
        },
        tsb = function(a) {
            var b, c;
            return a.HW || 0 < (null != (c = null == a ? void 0 : null == (b = a.bk) ? void 0 : b.length) ? c : 0)
        },
        y5 = function(a) {
            null != a.vk || (a.vk = []);
            null != a.Nr || (a.Nr = []);
            null != a.rB || (a.rB = [])
        },
        Asb = function(a, b, c) {
            function d(f) {
                e.gz = f
            }
            var e = Object.create(xsb);
            c && (e.VN = !0);
            e.gt = a;
            e.schedule = b;
            a = {};
            e.xB = (a.notify = function() {
                return rsb(e)
            }, a.DB = function() {
                if (null !== e.gt) {
                    if (x5) throw Error("Schedulers cannot synchronously execute watches while scheduling.");
                    e.Yl = !1;
                    if (!e.oY || wsb(e)) {
                        e.oY = !0;
                        var f = ssb(e);
                        try {
                            e.gz(), e.gz = ysb, e.gt(d)
                        } finally {
                            vsb(e, f)
                        }
                    }
                }
            }, a.Enb = function() {
                return e.gz()
            }, a.destroy = function() {
                if (null !== e.gt || null !== e.schedule) {
                    y5(e);
                    if (tsb(e))
                        for (var f = 0; f < e.vk.length; f++) usb(e.vk[f], e.Nr[f]);
                    e.vk.length = e.rB.length = e.Nr.length = 0;
                    e.bk && (e.bk.length = e.Rw.length = 0);
                    e.gz();
                    e.gt = null;
                    e.schedule = null;
                    e.gz = ysb
                }
            }, a[zsb] = e, a);
            return e.xB
        },
        ysb = function() {},
        Bsb = function(a) {
            return Object.create(Object.assign({}, z5, {
                VN: a
            }))
        },
        A5 = function(a, b) {
            a = w5(a);
            try {
                return b()
            } finally {
                w5(a)
            }
        },
        B5 = function(a) {
            var b = u5;
            if (b && b !== Csb) {
                if (b.Ma) throw Error("It is an error to run operations in disposed owners. See go/cow-errors#disposed-node for more information.");
                var c = p5.slice();
                b.vD || (b.vD = []);
                b.vD.push(function() {
                    return void s5(function() {
                        return void a()
                    }, {
                        stack: c
                    })
                })
            }
        },
        C5 = function(a) {
            var b = !!u5,
                c = Dsb(void 0 === b ? !0 : b);
            v5(c, function() {
                return void a(c)
            });
            return function() {
                return void Esb(c)
            }
        },
        Dsb = function(a) {
            var b = {};
            (void 0 === a || a) && Fsb(b);
            return b
        },
        Fsb = function(a) {
            var b = u5;
            b && (b.Ma || B5(function() {
                return void Esb(a)
            }))
        },
        Hsb = function(a) {
            a.vD && (A5(Gsb, function() {
                for (var b = g.u(a.vD), c = b.next(); !c.done; c = b.next()) c = c.value, c()
            }), a.vD = [])
        },
        Esb = function(a) {
            if (!a.Ma) {
                a.Ma = !0;
                var b;
                null == (b = a.M$) || b.call(a);
                Hsb(a)
            }
        },
        Isb = function() {
            if (q5()) throw Error("Reactive components are not allowed to use useState or other memoization based hooks.");
            return D5
        },
        E5 = function(a) {
            t5.call(this, a);
            var b = this;
            this.Xz = [];
            this.D = 0;
            this.G = C5(function(c) {
                b.wI = c;
                B5(function() {
                    Jsb(b, b.el)
                })
            })
        },
        Jsb = function(a, b) {
            if (!a.C && b) {
                a.C = !0;
                try {
                    a.sI()
                } catch (e) {
                    var c, d;
                    null == (d = r5.Sz) || d.call(r5, null == (c = a.j) ? void 0 : c.Av, e)
                }
                F5.sI(a);
                a.el = null;
                b.__instance && delete b.__instance
            }
        },
        Ksb = function(a) {
            if (a) {
                var b;
                null == (b = a._disposeRef) || b.call(a);
                var c;
                null == (c = a._disposeEffects) || c.call(a);
                a.__instance && a.__instance instanceof t5 && (b = a.__instance, Jsb(b, a), b instanceof E5 && b.G());
                for (b = 0; b < a.childNodes.length; b++) Ksb(a.childNodes[b])
            }
        },
        Msb = function(a) {
            1 === Lsb.push(a) && requestAnimationFrame(function() {
                setTimeout(function() {
                    var b = [].concat(g.qa(Lsb));
                    Lsb = [];
                    b = g.u(b);
                    for (var c = b.next(); !c.done; c = b.next()) {
                        c = c.value;
                        try {
                            for (var d = 0; d < c.length; d++) Ksb(c[d])
                        } catch (e) {
                            d = c = void 0, null == (d = (c = r5).Sz) || d.call(c, "unknown", e)
                        }
                    }
                })
            })
        },
        Nsb = function(a, b) {
            var c = g.Ia.apply(2, arguments),
                d;
            b = null != (d = b) ? d : {};
            d = {};
            return d.type = a, d.props = b, d.children = c, d[G5] = !0, d
        },
        H5 = function(a) {
            return a.children
        },
        J5 = function(a, b) {
            return I5.apply(null, [a,
                b
            ].concat(g.qa(g.Ia.apply(2, arguments))))
        },
        K5 = function(a, b) {
            var c = I5;
            I5 = a;
            try {
                return b()
            } finally {
                I5 = c
            }
        },
        L5 = function() {
            return document.createTextNode("")
        },
        M5 = function(a) {
            a = document.createTextNode(String(a));
            a._isSignalTextNode = !0;
            return a
        },
        N5 = function(a) {
            a = typeof a;
            return "string" === a || "number" === a || "boolean" === a
        },
        O5 = function(a) {
            return a instanceof g.Ud || a instanceof g.Zd || a instanceof g.ke || !1
        },
        Osb = function(a, b) {
            a.parentElement && a.parentElement.replaceChild(b, a);
            return b
        },
        Psb = function(a, b) {
            a.textContent !== String(b) && (a.textContent = String(b));
            return a
        },
        P5 = function(a, b) {
            var c = a[0].parentElement;
            if (c)
                if (a[0].previousSibling || a[a.length - 1].nextSibling) {
                    c.insertBefore(b, a[0]);
                    for (var d = a.length - 1; 0 <= d; d--) c.removeChild(a[d])
                } else c.textContent = "", c.appendChild(b);
            return b
        },
        Qsb = function(a, b) {
            if (a[0].parentElement)
                for (var c = a[0].parentElement, d = b.length, e = a.length, f = d, h = 0, l = 0, m = a[e - 1].nextSibling, n = null; h < e || l < f;)
                    if (a[h] === b[l]) h++, l++;
                    else {
                        for (; a[e - 1] === b[f - 1];) e--, f--;
                        if (e === h)
                            for (var p = f < d ? l ? b[l - 1].nextSibling : b[f - l] : m; l < f;) c.insertBefore(b[l++], p);
                        else if (f === l)
                            for (; h < e;) p = a[h], n && n.has(p) || c.removeChild(p), h++;
                        else if (a[h] === b[f - 1] && b[l] === a[e - 1]) p = a[--e].nextSibling, c.insertBefore(b[l++], a[h++].nextSibling), c.insertBefore(b[--f], p), a[e] = b[f];
                        else {
                            if (!n)
                                for (n = new Map, p = l; p < f;) n.set(b[p], p++);
                            p = n.get(a[h]);
                            if (null == p) c.removeChild(a[h]), h++;
                            else if (l < p && p < f) {
                                for (var q = h, r = 1, t = void 0; ++q < e && q < f && null != (t = n.get(a[q])) && t === p +
                                    r;) r++;
                                if (r > p - l)
                                    for (q = a[h]; l < p;) c.insertBefore(b[l++], q);
                                else c.replaceChild(b[l++], a[h++])
                            } else h++
                        }
                    }
            return b
        },
        Q5 = function(a) {
            return g.bb(a) ? "nodeType" in a : !1
        },
        Ssb = function(a) {
            a.Ma || Rsb.add(a)
        },
        Tsb = function(a) {
            return g.G(function(b) {
                if (1 == b.j) {
                    if (a.Ma) return b.return();
                    if (r5.jea) return g.z(b, Promise.resolve(), 6);
                    R5.add(a);
                    return 1 !== R5.size ? b.Ia(0) : g.z(b, Promise.resolve(), 5)
                }
                if (6 != b.j) {
                    for (var c = g.u(R5), d = c.next(); !d.done; d = c.next()) d = d.value, R5.delete(d), d.DB();
                    return b.Ia(0)
                }
                a.DB();
                g.Aa(b)
            })
        },
        Usb = function(a, b, c) {
            function d() {
                return void s5(b, {
                    stack: e
                })
            }
            var e = p5.slice(),
                f = Asb(function() {
                    f.Ma || (Hsb(f), v5(f, d))
                }, a, void 0 === c ? !1 : c);
            Fsb(f);
            f.M$ = function() {
                f.destroy();
                Rsb.delete(f);
                Esb(f)
            };
            return f
        },
        Vsb = function(a) {
            Usb(Ssb, a).DB()
        },
        Wsb = function(a) {
            Usb(Ssb, a, !0).DB()
        },
        Ysb = function(a) {
            var b = [];
            ({}.xnb ? Wsb : Vsb)(function() {
                var c = b[0],
                    d = b.Uq,
                    e = K5(S5, a);
                c = Xsb(c, e, b);
                Array.isArray(c) || (b.Uq = [c]);
                e = b.Uq;
                if (d) {
                    d = Array.isArray(d) ? d[0] : d;
                    var f = d[T5],
                        h = d._disposeEffects;
                    d._disposeEffects = void 0;
                    d = Array.isArray(e) ? e[0] : e;
                    d[T5] = f;
                    d[T5] && (d[T5].LZ = d === e ? 1 : e.length);
                    d._disposeEffects = h
                }
                b[0] = c
            });
            return b
        },
        Xsb = function(a, b, c) {
            for (;
                "function" === typeof b;) b = b();
            if (null != b && b[G5]) {
                var d;
                throw Error("Encountered a VNode when only real nodes are expected. Tag name: " + (null == (d = b.type) ? void 0 : d.Av));
            }
            if (null == a) return null == b ? L5() : N5(b) ? M5(b) : O5(b) ? M5(b.toString()) : Q5(b) ? b : 0 === b.length ? L5() : Zsb(b, c);
            if (Q5(a)) {
                if (null == b) return Osb(a, L5());
                if (N5(b)) return Psb(a, b);
                if (O5(b)) return Psb(a, b.toString());
                if (Q5(b)) return Osb(a, b);
                if (0 === b.length) return Osb(a, L5());
                b = Zsb(b, c);
                Qsb([a], c.Uq);
                return b
            }
            a = $sb(a);
            if (null == b) return P5(a, L5());
            if (N5(b)) return P5(a, M5(b));
            if (O5(b)) return P5(a,
                M5(b.toString()));
            if (Q5(b)) return Qsb(a, [b])[0];
            if (0 === b.length) return P5(a, L5());
            b = Zsb(b, c);
            Qsb(a, c.Uq);
            return b
        },
        $sb = function(a, b) {
            b = void 0 === b ? [] : b;
            return U5(a, b)
        },
        Zsb = function(a, b) {
            var c = U5(a, [], !0);
            if (0 === c.length) return L5();
            b.Uq = c;
            return a
        },
        U5 = function(a, b, c, d, e) {
            b = void 0 === b ? [] : b;
            c = void 0 === c ? !1 : c;
            e = void 0 === e ? -1 : e;
            if (null == a) return b;
            N5(a) && (a = M5(a), d && c && (d[e] = a));
            O5(a) && (a = M5(a.toString()), d && c && (d[e] = a));
            if (Q5(a)) return atb(b, a);
            if (Array.isArray(a)) {
                for (d = 0; d < a.length; d++) U5(a[d], b, c, a, d);
                return b
            }
            if ("function" === typeof a) return a = Ysb(a)[0], d && c && (d[e] = a), atb(b, a);
            if (null != a && a[G5]) {
                var f = a;
                a = K5(S5, function() {
                    return J5.apply(null, [f.type, f.props].concat(g.qa(f.children)))
                });
                return U5(a, b, c)
            }
            throw Error("Unrecognized JSXResult type in flattening.");
        },
        atb = function(a, b) {
            Array.isArray(a) ? a.push(b) : a.appendChild(b);
            return a
        },
        dtb = function(a, b, c) {
            if (Object.hasOwnProperty.call(btb, a) && (a = btb[a], Object.hasOwnProperty.call(a, b) && (a = a[b], a instanceof Array))) {
                for (var d = null, e = !1, f = 0, h = a.length; f < h; ++f) {
                    var l = a[f],
                        m = l.oi;
                    if (!m) return l.qd;
                    null === d && (d = {});
                    m = Object.hasOwnProperty.call(d, m) ? d[m] : d[m] = c(m);
                    if (m === l.Fi) return l.qd;
                    null == m && (e = !0)
                }
                if (e) return null
            }
            b = ctb[b];
            return "number" === typeof b ? b : null
        },
        ftb = function(a, b, c) {
            if (null === c || void 0 === c) return c;
            var d = dtb(a.tagName.toLowerCase(), b, function() {
                throw Error("Contingent attribute/property lookups are not supported.");
            });
            if (null === d) return c;
            d = etb[d];
            var e;
            if (null == (e = d.Qt) ? 0 : e.call(d, c)) {
                if (d.xs) return d.xs(c);
                throw Error("Value Handler's unwrap function does not exist.");
            }
            return d.Sq ? d.Sq(a.tagName, b, String(c)) : c
        },
        V5 = function(a, b, c) {
            if (!1 === c && gtb.has(b)) Xrb(a, b, null);
            else if ("idomKey" !== b && "skip" !== b && "skipchildren" !== b && "children" !== b && "el" !== b)
                if (b.startsWith("on"))
                    if (":" === b[2])
                        if (void 0 === c || null === c) {
                            var d;
                            null == (d = r5.Sz) || d.call(r5, a.tagName, Error("The " + b + " attribute was set to undefined or null. This is not supported and may lead to unexpected behavior if an event handler is being conditionally set."));
                            a[b] = void 0
                        } else {
                            if ("object" !== typeof c || null === c) throw Error("Expected " + b + " to be an EventHandler but its type was: " + (typeof c + ". Event handlers must be created using useHandler."));
                            if ("function" !== typeof c.xX) throw Error("Expected the event handler for " + b + " to have a 'getFn' property but its keys were: " + (Object.keys(c) + ". Event handlers must be created using useHandler."));
                            var e = c.xX(0),
                                f = b.slice(3);
                            if (q5()) a.addEventListener(f, e), B5(function() {
                                return void a.removeEventListener(f, e)
                            });
                            else {
                                if (htb.includes(f)) throw Error("The on:" + f + " attribute is not supported in an IDOM component because Element#on" + (f + " is not a valid property."));
                                a["on" + f] = e
                            }
                        }
            else itb(a, b, c);
            else "function" !== typeof c || null != a._disposeEffects ? (r5.m7 && (c = ftb(a, b, c)), "style" === b ? jtb(a, b, c) : b.startsWith("prop:") ? a[b.slice(5)] = c : itb(a, b, c)) : (a._signalProps || (a._signalProps = []), a._signalValues || (a._signalValues = []), a._signalProps.push(b))
        },
        ktb = function(a, b, c) {
            c = (void 0 === c ? {} : c).nA;
            if (null == b ? 0 : b.el) {
                var d = b.el;
                if ("function" === typeof d) d(a);
                else {
                    var e;
                    null == (e = d.Taa) || e.call(d, a);
                    a._disposeRef || (a._disposeRef = function() {
                        var f;
                        null == (f = d.Lba) || f.call(d);
                        delete a._disposeRef
                    }, c && B5(function() {
                        var f;
                        return void(null == (f = a._disposeRef) ? void 0 : f.call(a))
                    }))
                }
            }
        },
        mtb = function(a, b) {
            var c, d, e = C5(function(n) {
                    d = n;
                    c = K5(S5, function() {
                        return A5(ltb, function() {
                            return a(b)
                        })
                    })
                }),
                f = null != c && c.Uq ? c.Uq : c,
                h = Array.isArray(f) ? f[0] : f;
            if (h) {
                var l, m = null != (l = null == b ? void 0 : b.idomKey) ? l : a;
                l = a.T1;
                h._disposeEffects = e;
                e = h[T5] || {};
                Object.assign(e, {
                    key: m,
                    props: l ? b : void 0,
                    LZ: f !== h ? f.length : 1,
                    owner: d,
                    Y8: !!h[T5]
                });
                h[T5] = e
            } else e();
            v5(d, function() {});
            return c
        },
        ntb = function(a, b) {
            null == a._disposeEffects && null != a._signalProps && (a._disposeEffects = C5(function() {
                Vsb(function() {
                    for (var c = a._signalProps, d = a._signalValues, e = 0; e < c.length; e++) {
                        var f = c[e],
                            h = b[f]();
                        d[e] !== h && (d[e] = h, V5(a, f, h))
                    }
                })
            }))
        },
        otb = function(a, b) {
            a._disposeEffects = C5(function() {
                a._isSignalTextNode = !0;
                Vsb(function() {
                    var c = b();
                    null == c && (c = "");
                    var d = typeof c;
                    if ("object" === d || "function" === d) throw Error("Invalid text node kind: " + d + ". Text nodes must be primitives like numbers, strings, or null, but an object type was passed. See go/cow-errors#invalid-text-nodes for more information.");
                    a.textContent = String(c)
                })
            })
        },
        rtb = function(a, b) {
            var c = g.Ia.apply(2, arguments);
            null != b || (b = {});
            if (a === H5) return c;
            if ("function" === typeof a) return msb(a, function() {
                var f = b;
                0 < c.length && (f.children = 1 === c.length ? c[0] : c);
                var h = ptb(a, f);
                return !1 === h ? qtb(a, f) : h
            });
            var d = document.createElement(a),
                e;
            for (e in b) V5(d, e, b[e]);
            ntb(d, b);
            $sb(c, d);
            ktb(d, b, {
                nA: !0
            });
            return d
        },
        ptb = function(a, b) {
            if (a.bpb || a.nA) return !1;
            b || (b = {});
            var c = new E5(b);
            c.B = a;
            var d = A5(ltb, function() {
                return c.Ix(b)
            });
            if (!(d instanceof HTMLElement)) return d;
            d.__instance = c;
            c.el = d;
            c.j = a;
            a.Av = d.tagName.toLowerCase();
            F5.CD(c);
            return d
        },
        stb = function(a) {
            a = Usb(Tsb, a);
            Tsb(a)
        },
        ttb = function(a) {
            stb(function() {
                A5(null, a)
            })
        },
        utb = function(a) {
            var b = null,
                c;
            return {
                value: null,
                Taa: function(d) {
                    if (c && d !== c) {
                        var e;
                        null == (e = b) || e();
                        c._disposeRef = void 0
                    }
                    c = d;
                    b = a(d) || null
                },
                Lba: function() {
                    var d;
                    null == (d = b) || d()
                }
            }
        },
        vtb = function(a) {
            var b = Isb();
            if (null == b) throw Error("A valid hook context was not found. Please ensure you are using components from TSX and not invoking the component function directly");
            var c = b.D++;
            b.Xz || (b.Xz = []);
            var d = b.Xz;
            d[c] || (d[c] = {
                key: a,
                host: b
            });
            if (a !== d[c].key) {
                var e, f;
                a = (null == (e = b.j) ? void 0 : e.name) || (null == (f = b.B) ? void 0 : f.name);
                throw Error("Hook called out of order in " + a + ". Hooks must be invoked unconditionally and in the same order every render. This could happen if you conditionally invoke a hook.");
            }
            return d[c]
        },
        wtb = function(a, b) {
            return !a || a.length !== (null == b ? void 0 : b.length) || a.some(function(c, d) {
                return c !== b[d]
            })
        },
        xtb = function(a, b) {
            var c = vtb("onChange"),
                d = Isb();
            wtb(c.Vg, b) && (c.Vg = b, c.C_ = a, d.Ty || (d.Ty = []), d.Ty.push(c))
        },
        W5 = function(a, b) {
            xtb(function() {
                return A5(null, a)
            }, b)
        },
        ytb = function(a) {
            q5() ? ttb(function() {
                A5(null, a)
            }) : xtb(function() {
                return A5(null, a)
            }, [])
        },
        Atb = function(a) {
            var b = [].concat(g.qa(a));
            a.length = 0;
            a = g.u(b);
            for (b = a.next(); !b.done; b = a.next()) {
                b = b.value;
                ztb(b);
                var c = b.C_;
                b.C_ = null;
                if (c = null == c ? void 0 : c()) b.B_ = c
            }
        },
        ztb = function(a) {
            var b = a.B_;
            a.B_ = null;
            null == b || b()
        },
        X5 = function(a) {
            var b = [];
            if (q5()) return a();
            var c = vtb("useMemoInternal");
            wtb(c.Vg, b) && (c.Vg = b, c.value = a());
            return c.value
        },
        Y5 = function() {
            var a = X5(function() {
                return utb(function(b) {
                    a.value = b;
                    var c = A5(null, function() {});
                    return function() {
                        null == c || c();
                        a.value = null
                    }
                })
            });
            return a
        },
        Btb = function(a) {
            var b = u5,
                c = p5.slice();
            return {
                xX: function() {
                    return function(d) {
                        b.Ma || !0 !== s5(function() {
                            return a(d)
                        }, {
                            stack: c
                        }) && d.stopPropagation()
                    }
                }
            }
        },
        Ctb = function(a) {
            if ("function" === typeof a.children) return a.children(), null;
            a = g.u(a.children);
            for (var b = a.next(); !b.done; b = a.next()) b = b.value, b();
            return null
        },
        Etb = function(a, b, c) {
            c = void 0 === c ? !1 : c;
            s5(function() {
                return Dtb(a, b, c)
            })
        },
        Dtb = function(a, b, c) {
            c = ((void 0 === c ? 0 : c) ? Ftb : Gtb)(a, function() {
                Z5(b)
            });
            return null === c ? a : c
        },
        Z5 = function(a) {
            if (void 0 !== a && null !== a)
                if (Array.isArray(a)) {
                    a = g.u(a);
                    for (var b = a.next(); !b.done; b = a.next()) Z5(b.value)
                } else if (a instanceof g.Ud || a instanceof g.Zd || a instanceof g.ke) lsb(a.toString());
            else if (Q5(a)) {
                if (f5() !== a) throw Error("Encountered a real dom node where a vdom node was expected. Real dom nodes should only come from the reactive renderer, and they can't be passed in JSX expressions directly. Tag name: " + a.tagName);
                i5 = f5()
            } else {
                var c = typeof a;
                if ("boolean" === c || "number" === c || "string" === c) lsb(a);
                else if ("function" === typeof a) {
                    b = e5;
                    var d = f5();
                    if (!d ||
                        !d._isSignalTextNode) {
                        var e = b.insertBefore,
                            f = document.createTextNode("");
                        otb(f, a);
                        e.call(b, f, d)
                    }
                    i5 = f5()
                } else {
                    if ("string" === typeof a.type) {
                        a.Hq || hsb(a.type, a.props.idomKey);
                        b = e5;
                        for (e in a.props) a.props[e] !== Htb && (f = a.props[e], c = m5, c.push(e), c.push(f));
                        e = r5.attributes;
                        e = void 0 === e ? Itb : e;
                        f = e5;
                        var h = d5(f);
                        c = e;
                        e = m5;
                        h = h.j || (h.j = Wrb(e.length));
                        for (var l = !h.length || !1, m = 0; m < e.length; m += 2) {
                            var n = e[m];
                            if (l) h[m] = n;
                            else if (h[m] !== n) break;
                            var p = e[m + 1];
                            if (l || h[m + 1] !== p) h[m + 1] = p, ksb(f, n, p, c)
                        }
                        if (m < e.length || m < h.length) {
                            for (m =
                                l = m; m < h.length; m += 2) $5[h[m]] = h[m + 1];
                            for (m = l; m < e.length; m += 2) l = e[m], n = e[m + 1], $5[l] !== n && ksb(f, l, n, c), h[m] = l, h[m + 1] = n, delete $5[l];
                            c5(h, e.length);
                            for (d in $5) ksb(f, d, void 0, c), delete $5[d]
                        }
                        d = Jtb;
                        Jtb = f = o5.length;
                        for (c = d; c < f; c += 5)(0, o5[c])(o5[c + 1], o5[c + 2], o5[c + 3], o5[c + 4]);
                        Jtb = d;
                        c5(o5, d);
                        c5(e, 0);
                        ntb(b, a.props);
                        (a.props.skip || a.props.skipchildren) && e5.hasChildNodes() ? i5 = e5.lastChild : Z5(a.children);
                        h5(null);
                        i5 = e5;
                        e5 = e5.parentNode;
                        a.Hq && (a.Hq = !1);
                        ktb(b, a.props);
                        return b
                    }
                    if (a.type === H5) Z5(a.children);
                    else if (!Ktb(a)) {
                        try {
                            Ltb(a)
                        } catch (q) {
                            d =
                                q, null == (f = r5.Sz) || f.call(r5, null == (b = a.type) ? void 0 : b.Av, d)
                        }
                        a.Hq && (h5(null), i5 = e5, e5 = e5.parentNode, a.Hq = !1)
                    }
                }
            }
        },
        Mtb = function(a, b) {
            var c;
            void 0 === (null == (c = a.prototype) ? void 0 : c.Ix) ? (b = new E5(b), b.B = a) : b = new a(b);
            b.j = a;
            b.cN = {
                DQ: b.state,
                LY: !1
            };
            return b
        },
        Ltb = function(a) {
            var b = a.type,
                c = b.Av;
            if (b === Ctb) a.props.children = a.children, b(a.props);
            else {
                0 < a.children.length && (a.props.children = a.children);
                var d;
                (d = a.props).idomKey || (d.idomKey = b);
                if (c) {
                    var e = hsb(c, a.props.idomKey);
                    a.Hq = !0;
                    var f = e.__instance
                }
                f || (f = Mtb(b, a.props), f.props = null, e && (e.__instance = f, f.el = e));
                var h;
                c = (null != (h = f.cN) ? h : {
                    DQ: f.state,
                    LY: !1
                }).DQ;
                f.cN = void 0;
                b.Q7 && (c = b.Q7(a.props, c));
                f.props = a.props;
                f.state = c;
                h = function() {
                    var l = f;
                    F5.iW(l);
                    var m = l.Ix(l.props);
                    m ? (l.props.idomKey && (m.props.idomKey = l.props.idomKey), l = m) : l = void 0;
                    if (m = l)
                        if (m.Hq = a.Hq, l = Z5(m), a.Hq = m.Hq, !b.Av)
                            if (l) b.Av = l.tagName.toLowerCase(), l.__instance = f, f.el = l;
                            else {
                                var n;
                                if (null == (n = f.Xz) ? 0 : n.length) {
                                    var p;
                                    null == (p = r5.Sz) || p.call(r5, "unknown", Error("A component used hooks, but failed to return a host element"))
                                }
                            }
                    f.CD();
                    F5.CD(f)
                };
                (c = f.B) ? msb(c, h): h()
            }
        },
        Ktb = function(a) {
            var b = a.type;
            if (!b.nA) return !1;
            a.props.children = 1 < a.children.length ? a.children : a.children[0];
            var c, d = null != (c = a.props.idomKey) ? c : a.type,
                e;
            if (f5() && (null == (e = f5()[T5]) ? void 0 : e.key) === d) {
                d = f5();
                c = d[T5];
                if (!c) throw Error("Reactive data has been lost on node. Tag name: " + d.tagName);
                d = c.LZ;
                if (!b.T1) {
                    for (b = 0; b < d; b++) i5 = f5();
                    var f;
                    null == (f = c.Gqb) || f.call(c, a.props);
                    return !0
                }
                f = u5;
                b = b.T1(a.props, c.props, null !== f ? f : c.owner, c.Y8);
                f = Ntb(b);
                Otb(a.props, c.props);
                0 < f ? Z5(b) : i5 = f5();
                return !0
            }
            if (b = msb(a.type, function() {
                    return qtb(a.type,
                        a.props)
                }))
                for (b = null != b && b.Uq ? b.Uq : b, b = Array.isArray(b) ? b : [b], b = g.u(b), c = b.next(); !c.done; c = b.next()) e5.insertBefore(c.value, f5()), i5 = f5();
            return !0
        },
        Ntb = function(a) {
            if (a) {
                if (Array.isArray(a)) {
                    var b = 0;
                    a = g.u(a);
                    for (var c = a.next(); !c.done; c = a.next())(c = c.value) && (b = c.type === H5 ? b + c.children.length : b + 1);
                    return b
                }
                if (a.type === H5) return a.children.length
            } else return 0;
            return 1
        },
        Otb = function(a, b) {
            b && (b.children = a.children, b.l7 = a.l7, b.fallback = a.fallback)
        },
        Ptb = function(a) {
            var b = Isb(),
                c = X5(function() {
                    return {
                        value: "function" === typeof a ? a() : a
                    }
                });
            return [c.value, function(d) {
                if (null !== D5) throw Error("Can't set state during rendering");
                c.value = "function" === typeof d ? d(c.value) : d;
                b.cN = {
                    DQ: b.state,
                    LY: !0
                };
                v5(b.wI, function() {
                    K5(Nsb, function() {
                        if (b.el) {
                            var e, f = {},
                                h = (f.props = b.props, f.type = b.j, f.children = null != (e = b.props.children) ? e : [], f[G5] = !0, f);
                            try {
                                Etb(b.el, h, !0)
                            } catch (n) {
                                var l, m;
                                null == (m = r5.Sz) || m.call(r5, null == (l = b.j) ? void 0 : l.Av, n)
                            }
                        }
                    })
                })
            }]
        },
        Qtb = function() {
            return X5(function() {
                return {
                    value: null
                }
            })
        },
        Utb = function(a) {
            var b = Rtb;
            Stb.push(a);
            Ttb || (b(function() {
                for (var c = g.u(Stb), d = c.next(); !d.done; d = c.next()) d = d.value, d();
                Stb.length = 0;
                Ttb = !1
            }), Ttb = !0)
        },
        Rtb = function(a) {
            Promise.resolve().then(a)
        },
        Vtb = function(a) {
            a = g.u(Ptb(a));
            var b = a.next().value,
                c = a.next().value;
            return [b, function(d) {
                Utb(function() {
                    c(d)
                })
            }]
        },
        Wtb = function(a) {
            function b() {
                var l = a.J.Wc() ? "Hide more shorts" : "Hide more videos";
                e(l)
            }
            var c = g.u(Ptb("Hide more videos")),
                d = c.next().value,
                e = c.next().value;
            W5(function() {
                var l = a.J;
                l.addEventListener("videodatachange", b);
                return function() {
                    l.removeEventListener("videodatachange", b)
                }
            }, [a.J]);
            var f = X5(function() {
                    return (new g.eF(g.sF())).element
                }),
                h = Y5();
            ytb(function() {
                h.value.appendChild(f)
            });
            return J5("button", {
                class: "ytp-button ytp-collapse",
                "aria-label": d,
                "on:click": Btb(function() {
                    a.action && a.action()
                })
            }, J5("div", {
                class: "ytp-collapse-icon",
                el: h,
                skip: !0
            }))
        },
        Xtb = function(a) {
            function b() {
                var h = a.J.Wc() ? "More shorts" : "More videos";
                e(h)
            }
            var c = g.u(Vtb("More videos")),
                d = c.next().value,
                e = c.next().value,
                f = Y5();
            W5(function() {
                a.xB && (a.xB.value = f.value)
            }, [a.xB]);
            W5(function() {
                var h = a.J;
                h.addEventListener("videodatachange", b);
                return function() {
                    h.removeEventListener("videodatachange", b)
                }
            }, [a.J]);
            return J5("button", {
                el: f,
                class: "ytp-button ytp-expand",
                "on:click": Btb(function() {
                    a.action && a.action()
                })
            }, d)
        },
        Ytb = function(a, b) {
            var c = Qtb();
            W5(function() {
                var d = new g.f2(a);
                d.B = !0;
                c.value = d;
                return function() {
                    var e;
                    null == (e = c.value) || e.dispose()
                }
            }, [a,
                b
            ]);
            return c
        },
        Ztb = function(a) {
            function b(w) {
                a: {
                    var A = g.u([1,
                        16, 32
                    ]);
                    for (var D = A.next(); !D.done; D = A.next())
                        if (g.SF(w, D.value)) {
                            A = !0;
                            break a
                        }
                    A = !1
                }
                if (!A) {
                    var F;
                    null != (F = p.value) && 0 < F.suggestionData.length && h(g.SF(w, 4) && !g.SF(w, 2) && !g.SF(w, 1024))
                }
            }

            function c() {
                b(a.J.getPlayerStateObject())
            }

            function d(w) {
                b(w.state)
            }
            var e = g.u(Vtb(!1)),
                f = e.next().value,
                h = e.next().value,
                l = g.u(Vtb(!1));
            e = l.next().value;
            var m = l.next().value,
                n = Y5(),
                p = Ytb(a.J, a.Qe),
                q = Y5();
            l = Qtb();
            var r = Qtb();
            W5(function() {
                var w = a.J,
                    A = w.Wc() ? 157212 : 172777;
                r.value = new g.I;
                w.createClientVe(q.value, r.value, A);
                w.addEventListener("presentingplayerstatechange", d);
                w.addEventListener("videodatachange", c);
                A = "0" === w.U().controlsType;
                g.Dv(w.getRootNode(), "ytp-pause-overlay-controls-hidden", A);
                return function() {
                    w.removeEventListener("videodatachange", c);
                    w.removeEventListener("presentingplayerstatechange",
                        d);
                    var D;
                    null == (D = r.value) || D.dispose()
                }
            }, [a.J]);
            W5(function() {
                var w;
                null == (w = p.value) || w.Ja(n.value)
            }, [p]);
            var t = a.J;
            if (f)
                if (g.Dv(t.getRootNode(), "ytp-expand-pause-overlay", !e), e) l.value.focus();
                else {
                    var v = p.value;
                    g.g2(v);
                    v.show();
                    q.value.focus()
                }
            q.value && t.logVisibility(q.value, f && !e);
            return J5("ytp-pause-overlay", {
                el: q,
                class: "ytp-pause-overlay",
                "aria-hidden": !f
            }, J5(Wtb, {
                J: a.J,
                Qe: a.Qe,
                action: function() {
                    m(!0)
                }
            }), J5(Xtb, {
                J: a.J,
                Qe: a.Qe,
                action: function() {
                    m(!1)
                },
                xB: l
            }), J5("div", {
                el: n,
                skip: !0
            }))
        },
        $tb = function(a) {
            g.W.call(this, {
                I: "div",
                S: "ytp-related-on-error-overlay"
            });
            var b = this;
            this.api = a;
            this.K = this.B = 0;
            this.G = new g.dK(this);
            this.j = [];
            this.suggestionData = [];
            this.columns = this.containerWidth = 0;
            this.title = new g.W({
                I: "h2",
                S: "ytp-related-title",
                xa: "{{title}}"
            });
            this.previous = new g.W({
                I: "button",
                Ka: ["ytp-button", "ytp-previous"],
                X: {
                    "aria-label": "Show previous suggested videos"
                },
                V: [g.nF()]
            });
            this.qa = new g.e2(function(f) {
                b.suggestions.element.scrollLeft = -f
            });
            this.D = this.C = 0;
            this.N = !0;
            this.next = new g.W({
                I: "button",
                Ka: ["ytp-button", "ytp-next"],
                X: {
                    "aria-label": "Show more suggested videos"
                },
                V: [g.oF()]
            });
            g.N(this, this.G);
            a = a.U();
            this.api.L("embeds_web_enable_pause_overlay_rounding") && g.zv(this.element, "ytp-error-overlay-round-corners");
            this.Y = a.D;
            g.N(this, this.title);
            this.title.Ja(this.element);
            this.suggestions = new g.W({
                I: "div",
                S: "ytp-suggestions"
            });
            g.N(this, this.suggestions);
            this.suggestions.Ja(this.element);
            g.N(this, this.previous);
            this.previous.Ja(this.element);
            this.previous.listen("click", this.R3, this);
            g.N(this, this.qa);
            for (var c = {
                    bA: 0
                }; 16 > c.bA; c = {
                    bA: c.bA
                }, c.bA++) {
                var d = new g.W({
                    I: "a",
                    S: "ytp-suggestion-link",
                    X: {
                        href: "{{link}}",
                        target: a.Y,
                        "aria-label": "{{aria_label}}"
                    },
                    V: [{
                        I: "div",
                        S: "ytp-suggestion-image",
                        V: [{
                            I: "div",
                            X: {
                                "data-is-live": "{{is_live}}"
                            },
                            S: "ytp-suggestion-duration",
                            xa: "{{duration}}"
                        }]
                    }, {
                        I: "div",
                        S: "ytp-suggestion-title",
                        X: {
                            title: "{{hover_title}}"
                        },
                        xa: "{{title}}"
                    }, {
                        I: "div",
                        S: "ytp-suggestion-author",
                        xa: "{{views_or_author}}"
                    }]
                });
                g.N(this, d);
                d.Ja(this.suggestions.element);
                var e = d.Ga("ytp-suggestion-link");
                g.Fs(e, "transitionDelay", c.bA / 20 + "s");
                this.G.T(e, "click", function(f) {
                    return function(h) {
                        var l = f.bA,
                            m = b.suggestionData[l],
                            n = m.sessionData;
                        g.DR(b.api.U()) && b.api.L("web_player_log_click_before_generating_ve_conversion_params") ? (b.api.logClick(b.j[l].element), l = m.Ok(), m = {}, g.jXa(b.api, m, "emb_rel_err"), l = g.Sn(l, m), g.oU(l, b.api, h)) : g.nU(h, b.api, b.Y, n || void 0) && b.api.Mo(m.videoId, n, m.playlistId)
                    }
                }(c));
                this.j.push(d)
            }
            g.N(this, this.next);
            this.next.Ja(this.element);
            this.next.listen("click", this.Q3, this);
            this.G.T(this.api, "videodatachange", this.onVideoDataChange);
            this.resize(this.api.ob().getPlayerSize());
            this.onVideoDataChange();
            this.show()
        },
        aub = function(a, b) {
            if (a.api.U().L("web_player_log_click_before_generating_ve_conversion_params"))
                for (var c = Math.floor(-a.C / (a.D + a.B)), d = Math.min(c + a.columns, a.suggestionData.length) - 1; c <= d; c++) a.api.logVisibility(a.j[c].element, b)
        },
        bub = function(a) {
            a.next.element.style.bottom =
                a.K + "px";
            a.previous.element.style.bottom = a.K + "px";
            var b = a.C,
                c = a.containerWidth - a.suggestionData.length * (a.D + a.B);
            g.Dv(a.element, "ytp-scroll-min", 0 <= b);
            g.Dv(a.element, "ytp-scroll-max", b <= c)
        },
        cub = function(a) {
            for (var b = 0; b < a.suggestionData.length; b++) {
                var c = a.suggestionData[b],
                    d = a.j[b],
                    e = c.shortViewCount ? c.shortViewCount : c.author,
                    f = c.Ok(),
                    h = a.api.U();
                if (g.DR(h) && !h.L("web_player_log_click_before_generating_ve_conversion_params")) {
                    var l = {};
                    g.ET(a.api, "addEmbedsConversionTrackingParams", [l]);
                    f = g.Sn(f, g.YO(l, "emb_rel_err"))
                }
                d.element.style.display = "";
                l = d.Ga("ytp-suggestion-title");
                g.Hv.test(c.title) ? l.dir = "rtl" : g.vkb.test(c.title) && (l.dir = "ltr");
                l = d.Ga("ytp-suggestion-author");
                g.Hv.test(e) ? l.dir = "rtl" : g.vkb.test(e) && (l.dir = "ltr");
                d.update({
                    views_or_author: e,
                    duration: c.isLivePlayback ? "Live" : c.lengthSeconds ? g.bG(c.lengthSeconds) : "",
                    link: f,
                    hover_title: c.title,
                    title: c.title,
                    aria_label: c.ariaLabel || null,
                    is_live: c.isLivePlayback
                });
                e = d.Ga("ytp-suggestion-image");
                f = c.Zg();
                e.style.backgroundImage = f ? "url(" + f + ")" : "";
                h.L("web_player_log_click_before_generating_ve_conversion_params") && (a.api.createServerVe(d.element, d), (c = (c = c.sessionData) && c.itct) && a.api.setTrackingParams(d.element, c))
            }
            for (; b < a.j.length; b++) a.j[b].element.style.display = "none";
            bub(a)
        },
        a6 = function(a) {
            g.RV.call(this, a);
            var b = this;
            this.j = null;
            var c = a.U(),
                d = {
                    target: c.Y
                },
                e = ["ytp-small-redirect"];
            c.C ? e.push("no-link") : (c = g.aS(c), d.href = c, d["aria-label"] = "Visit YouTube to search for more videos");
            var f = new g.W({
                I: "a",
                Ka: e,
                X: d,
                V: [{
                    I: "svg",
                    X: {
                        fill: "#fff",
                        height: "100%",
                        viewBox: "0 0 24 24",
                        width: "100%"
                    },
                    V: [{
                        I: "path",
                        X: {
                            d: "M0 0h24v24H0V0z",
                            fill: "none"
                        }
                    }, {
                        I: "path",
                        X: {
                            d: "M21.58 7.19c-.23-.86-.91-1.54-1.77-1.77C18.25 5 12 5 12 5s-6.25 0-7.81.42c-.86.23-1.54.91-1.77 1.77C2 8.75 2 12 2 12s0 3.25.42 4.81c.23.86.91 1.54 1.77 1.77C5.75 19 12 19 12 19s6.25 0 7.81-.42c.86-.23 1.54-.91 1.77-1.77C22 15.25 22 12 22 12s0-3.25-.42-4.81zM10 15V9l5.2 3-5.2 3z"
                        }
                    }]
                }]
            });
            f.Ja(this.element);
            a.createClientVe(f.element, this, 178053);
            this.T(f.element, "click", function(h) {
                dub(b, h, f.element)
            });
            g.N(this, f);
            a.U().C || (this.j = new $tb(a), this.j.Ja(this.element), g.N(this, this.j));
            this.T(a, "videodatachange", function() {
                b.show()
            });
            this.resize(this.api.ob().getPlayerSize())
        },
        dub = function(a, b, c) {
            b.preventDefault();
            a.api.logClick(c);
            b = c.getAttribute("href");
            c = {};
            g.ET(a.api, "addEmbedsConversionTrackingParams", [c]);
            b = g.id(c) ? b : g.Sn(b, c);
            g.Ne(b)
        },
        eub = function(a, b) {
            a.Ga("ytp-error-content").style.paddingTop = "0px";
            var c = a.Ga("ytp-error-content"),
                d = c.clientHeight;
            a.j && a.j.resize(b, b.height - d);
            c.style.paddingTop = (b.height - (a.j ? a.j.element.clientHeight : 0)) / 2 - d / 2 + "px"
        },
        hub = function(a, b) {
            var c = a.api.U(),
                d;
            b.reason && (fub(b.reason) ? d = g.mF(b.reason) : d = g.SV(g.lF(b.reason)), a.Jd(d, "content"));
            var e;
            b.subreason && (fub(b.subreason) ? e = g.mF(b.subreason) : e = g.SV(g.lF(b.subreason)), a.Jd(e, "subreason"));
            if (b.proceedButton && b.proceedButton.buttonRenderer) {
                d = a.Ga("ytp-error-content-wrap-subreason");
                b = b.proceedButton.buttonRenderer;
                var f = g.yf("A");
                if (b.text && b.text.simpleText && (e = b.text.simpleText, f.textContent = e, !gub(d, e) && (!c.C || c.embedsErrorLinks))) {
                    var h;
                    c = null == (h = g.V(null == b ? void 0 : b.navigationEndpoint, g.yF)) ?
                        void 0 : h.url;
                    var l;
                    h = null == (l = g.V(null == b ? void 0 : b.navigationEndpoint, g.yF)) ? void 0 : l.target;
                    c && (f.setAttribute("href", c), a.api.createClientVe(f, a, 178424), a.T(f, "click", function(m) {
                        dub(a, m, f)
                    }));
                    h && f.setAttribute("target", h);
                    l = g.yf("DIV");
                    l.appendChild(f);
                    d.appendChild(l)
                }
            }
        },
        fub = function(a) {
            if (a.runs)
                for (var b = 0; b < a.runs.length; b++)
                    if (a.runs[b].navigationEndpoint) return !0;
            return !1
        },
        gub = function(a, b) {
            a = g.lf("A", a);
            for (var c = 0; c < a.length; c++)
                if (a[c].textContent === b) return !0;
            return !1
        },
        iub = function(a, b) {
            g.W.call(this, {
                I: "a",
                Ka: ["ytp-impression-link"],
                X: {
                    target: "{{target}}",
                    href: "{{url}}",
                    "aria-label": "Watch on YouTube"
                },
                V: [{
                    I: "div",
                    S: "ytp-impression-link-content",
                    X: {
                        "aria-hidden": "true"
                    },
                    V: [{
                        I: "div",
                        S: "ytp-impression-link-text",
                        xa: "Watch on"
                    }, {
                        I: "div",
                        S: "ytp-impression-link-logo",
                        xa: "{{logoSvg}}"
                    }]
                }]
            });
            this.api = a;
            this.Qe = b;
            this.updateValue("target", a.U().Y);
            this.T(a, "videodatachange", this.onVideoDataChange);
            this.T(this.api, "presentingplayerstatechange", this.hk);
            this.T(this.api, "videoplayerreset", this.ZT);
            this.T(this.element,
                "click", this.onClick);
            this.onVideoDataChange();
            this.ZT()
        },
        jub = function(a) {
            var b = {};
            g.ET(a.api, "addEmbedsConversionTrackingParams", [b]);
            return g.Sn(a.api.getVideoUrl(), g.YO(b, "emb_imp_woyt"))
        },
        b6 = function(a) {
            g.W.call(this, {
                I: "div",
                Ka: ["ytp-mobile-a11y-hidden-seek-button"],
                V: [{
                    I: "button",
                    Ka: ["ytp-mobile-a11y-hidden-seek-button-rewind", "ytp-button"],
                    X: {
                        "aria-label": "Rewind 10 seconds",
                        "aria-hidden": "false"
                    }
                }, {
                    I: "button",
                    Ka: ["ytp-mobile-a11y-hidden-seek-button-forward", "ytp-button"],
                    X: {
                        "aria-label": "Fast forward 10 seconds",
                        "aria-hidden": "false"
                    }
                }]
            });
            this.api = a;
            this.j = this.Ga("ytp-mobile-a11y-hidden-seek-button-rewind");
            this.forwardButton = this.Ga("ytp-mobile-a11y-hidden-seek-button-forward");
            this.api.createClientVe(this.j, this,
                141902);
            this.api.createClientVe(this.forwardButton, this, 141903);
            this.T(this.api, "presentingplayerstatechange", this.hk);
            this.T(this.j, "click", this.B);
            this.T(this.forwardButton, "click", this.C);
            this.hk()
        },
        c6 = function(a) {
            g.W.call(this, {
                I: "div",
                S: "ytp-muted-autoplay-endscreen-overlay",
                V: [{
                    I: "div",
                    S: "ytp-muted-autoplay-end-panel",
                    V: [{
                        I: "button",
                        Ka: ["ytp-muted-autoplay-end-text", "ytp-button"],
                        xa: "{{text}}"
                    }]
                }]
            });
            this.api = a;
            this.D = this.Ga("ytp-muted-autoplay-end-panel");
            this.B = !1;
            this.api.createClientVe(this.element, this, 52428);
            this.T(this.api, "presentingplayerstatechange", this.C);
            this.T(a, "onMutedAutoplayStarts", this.onMutedAutoplayStarts);
            this.listen("click", this.onClick);
            this.hide()
        },
        d6 = function(a) {
            var b = a.U();
            g.W.call(this, {
                I: "a",
                Ka: ["ytp-watermark", "yt-uix-sessionlink"],
                X: {
                    target: b.Y,
                    href: "{{url}}",
                    "aria-label": g.rJ("Watch on $WEBSITE", {
                        WEBSITE: g.PR(b)
                    }),
                    "data-sessionlink": "feature=player-watermark"
                },
                xa: "{{logoSvg}}"
            });
            this.api = a;
            this.j = null;
            this.B = !1;
            this.state = a.getPlayerStateObject();
            this.T(a, "videodatachange", this.onVideoDataChange);
            this.T(a, "presentingplayerstatechange", this.onStateChange);
            this.T(a, "appresize", this.dc);
            this.onVideoDataChange();
            this.Dc(this.state);
            this.dc(a.ob().getPlayerSize())
        },
        kub = function(a) {
            var b = a.api.getVideoData(),
                c = a.api.U().Rd && !g.SF(a.state, 2) && !g.xT(a.api.getVideoData(1));
            b.mutedAutoplay || g.hF(a, c);
            a.api.logVisibility(a.element, c)
        },
        nub = function(a) {
            g.W.call(this, {
                I: "div",
                S: "ytp-muted-autoplay-overlay",
                V: [{
                    I: "div",
                    S: "ytp-muted-autoplay-bottom-buttons",
                    V: [{
                        I: "button",
                        Ka: ["ytp-muted-autoplay-equalizer", "ytp-button"],
                        X: {
                            "aria-label": "Muted Playback Indicator"
                        },
                        V: [{
                            I: "div",
                            Ka: ["ytp-muted-autoplay-equalizer-icon"],
                            V: [{
                                I: "svg",
                                X: {
                                    height: "100%",
                                    version: "1.1",
                                    viewBox: "-4 -4 24 24",
                                    width: "100%"
                                },
                                V: [{
                                    I: "g",
                                    X: {
                                        fill: "#fff"
                                    },
                                    V: [{
                                            I: "rect",
                                            S: "ytp-equalizer-bar-left",
                                            X: {
                                                height: "9",
                                                width: "4",
                                                x: "1",
                                                y: "7"
                                            }
                                        }, {
                                            I: "rect",
                                            S: "ytp-equalizer-bar-middle",
                                            X: {
                                                height: "14",
                                                width: "4",
                                                x: "6",
                                                y: "2"
                                            }
                                        },
                                        {
                                            I: "rect",
                                            S: "ytp-equalizer-bar-right",
                                            X: {
                                                height: "12",
                                                width: "4",
                                                x: "11",
                                                y: "4"
                                            }
                                        }
                                    ]
                                }]
                            }]
                        }]
                    }]
                }]
            });
            var b = this;
            this.api = a;
            this.bottomButtons = this.Ga("ytp-muted-autoplay-bottom-buttons");
            this.Ga("ytp-muted-autoplay-equalizer");
            this.C = new g.qv(this.X8, 4E3, this);
            this.B = !1;
            a.createClientVe(this.element, this, 39306);
            this.T(a, "presentingplayerstatechange", this.qM);
            this.T(a, "onMutedAutoplayStarts", function() {
                lub(b);
                b.qM();
                mub(b);
                b.B = !1
            });
            this.T(a, "onAutoplayBlocked", this.onAutoplayBlocked);
            this.listen("click", this.onClick);
            this.T(a, "onMutedAutoplayEnds", this.onMutedAutoplayEnds);
            this.hide();
            g.IT(a.app) && (lub(this), this.qM(), mub(this));
            g.N(this, this.C)
        },
        mub = function(a) {
            a.Fb && a.j && (a.j.show(), a.C.start())
        },
        lub = function(a) {
            a.watermark || (a.watermark = new d6(a.api), g.N(a, a.watermark), a.watermark.Ja(a.bottomButtons, 0), g.Dv(a.watermark.element, "ytp-muted-autoplay-watermark", !0), a.j = new g.MF(a.watermark, 0, !0, 100), g.N(a, a.j))
        },
        e6 = function(a) {
            g.W.call(this, {
                I: "div",
                S: "ytp-pause-overlay",
                X: {
                    tabIndex: "-1"
                }
            });
            var b = this;
            this.api = a;
            this.C = new g.dK(this);
            this.D = new g.MF(this, 1E3, !1, 100, function() {
                b.j.B = !1
            }, function() {
                b.j.B = !0
            });
            this.B = !1;
            this.expandButton = new g.W({
                I: "button",
                Ka: ["ytp-button", "ytp-expand"],
                xa: this.api.Wc() ? "More shorts" : "More videos"
            });
            "0" === a.U().controlsType && g.zv(a.getRootNode(), "ytp-pause-overlay-controls-hidden");
            this.api.L("embeds_web_enable_pause_overlay_rounding") && g.zv(this.element, "ytp-pause-overlay-round-corners");
            g.N(this, this.C);
            g.N(this, this.D);
            var c = new g.W({
                I: "button",
                Ka: ["ytp-button", "ytp-collapse"],
                X: {
                    "aria-label": this.api.Wc() ? "Hide more shorts" : "Hide more videos"
                },
                V: [{
                    I: "div",
                    S: "ytp-collapse-icon",
                    V: [g.sF()]
                }]
            });
            g.N(this, c);
            c.Ja(this.element);
            c.listen("click", this.G, this);
            g.N(this, this.expandButton);
            this.expandButton.Ja(this.element);
            this.expandButton.listen("click", this.K, this);
            this.j = new g.f2(a);
            g.N(this, this.j);
            this.j.B = !1;
            this.j.Ja(this.element);
            this.api.Wc() ? this.api.createClientVe(this.element, this, 157212) : this.api.createClientVe(this.element, this, 172777);
            this.C.T(this.api, "presentingplayerstatechange", this.Ta);
            this.C.T(this.api, "videodatachange", this.Ta);
            this.hide()
        },
        f6 = function(a) {
            g.W.call(this, {
                I: "div",
                Ka: ["ytp-player-content", "ytp-iv-player-content"],
                V: [{
                    I: "div",
                    S: "ytp-countdown-timer",
                    V: [{
                        I: "svg",
                        X: {
                            height: "100%",
                            version: "1.1",
                            viewBox: "0 0 72 72",
                            width: "100%"
                        },
                        V: [{
                            I: "circle",
                            S: "ytp-svg-countdown-timer-ring",
                            X: {
                                cx: "-36",
                                cy: "36",
                                "fill-opacity": "0",
                                r: "33.5",
                                stroke: "#FFFFFF",
                                "stroke-dasharray": "211",
                                "stroke-dashoffset": "-211",
                                "stroke-width": "4",
                                transform: "rotate(-90)"
                            }
                        }, {
                            I: "circle",
                            S: "ytp-svg-countdown-timer-background",
                            X: {
                                cx: "-36",
                                cy: "36",
                                "fill-opacity": "0",
                                r: "33.5",
                                stroke: "#FFFFFF",
                                "stroke-opacity": "0.3",
                                "stroke-width": "4",
                                transform: "rotate(-90)"
                            }
                        }]
                    }, {
                        I: "span",
                        S: "ytp-countdown-timer-time",
                        xa: "{{duration}}"
                    }]
                }]
            });
            this.api = a;
            this.K = this.Ga("ytp-svg-countdown-timer-ring");
            this.j = null;
            this.D = this.C = 0;
            this.B = !1;
            this.G = 0;
            this.api.createClientVe(this.element, this, 159628)
        },
        pub = function(a) {
            a.j || (a.C = 5E3, a.D = (0, g.EC)(), a.j = new g.pv(function() {
                oub(a)
            }, null), oub(a))
        },
        oub = function(a) {
            if (!a.B) {
                var b = Math.min((0, g.EC)() - a.D, a.C);
                var c = a.C - b;
                b = 0 === a.C ? 0 : Math.max(c / a.C, 0);
                c = Math.round(c / 1E3);
                a.K.setAttribute("stroke-dashoffset", "" + -211 * (b + 1));
                a.updateValue("duration", c);
                0 >= b && a.j ? g6(a) : a.j && a.j.start()
            }
        },
        g6 = function(a) {
            a.j && (a.j.dispose(), a.j = null, a.B = !1)
        },
        rub = function(a) {
            g.uV.call(this, a);
            this.J = a;
            this.j = new g.dK(this);
            this.B = null;
            this.N = !1;
            this.countdownTimer = null;
            this.Y = !1;
            qub(this);
            g.N(this, this.j);
            this.load()
        },
        tub = function(a) {
            var b = g.Mib(a.J);
            b !== a.Y && (a.Y = b, a.G && (a.G.dispose(), a.G = null), a.C && (a.C.dispose(), a.C = null), a.D && (a.D.dispose(), a.D = null), a.B && (a.B.stop(), a.B.dispose(), a.B = null), b && (b = g.KT(a.J), a.J.Wc() && (a.D = new g.W({
                    I: "div",
                    S: "ytp-pause-overlay-backdrop",
                    X: {
                        tabIndex: "-1"
                    }
                }), g.N(a, a.D), g.WT(a.J, a.D.element, 4), a.B = new g.MF(a.D, 1E3, !1, 100), g.N(a, a.B), a.D.hide()), a.G = new g.W({
                    I: "div",
                    S: "ytp-pause-overlay-container",
                    X: {
                        tabIndex: "-1"
                    }
                }), g.N(a, a.G), a.J.L("embeds_web_enable_keto_pause_overlay") ? Etb(a.G.element, J5(Ztb, {
                    J: a.J,
                    Qe: b
                })) :
                (a.C = new e6(a.J, b), g.N(a, a.C), a.C.Ja(a.G.element)), g.WT(a.J, a.G.element, 4), sub(a, a.J.getPlayerStateObject())))
        },
        sub = function(a, b) {
            a.B && (!g.SF(b, 4) && !g.SF(b, 2) || g.SF(b, 1024) ? a.B.hide() : a.B.show())
        },
        qub = function(a) {
            var b = a.J;
            a = !!b.Wc();
            g.Dv(b.getRootNode(), "ytp-shorts-mode", a);
            if (b = b.getVideoData()) b.GV = a
        },
        h6 = function(a, b) {
            var c = a.J.U();
            a = {
                adSource: "EMBEDS_AD_SOURCE_YOUTUBE",
                breakType: 0 === a.J.getCurrentTime() ? "EMBEDS_AD_BREAK_TYPE_PRE_ROLL" : 0 === a.J.getPlayerState() ? "EMBEDS_AD_BREAK_TYPE_POST_ROLL" : "EMBEDS_AD_BREAK_TYPE_MID_ROLL",
                embedUrl: g.xfa(a.J.U().loaderUrl),
                eventType: b,
                youtubeHost: g.Mn(a.J.U().Fa) || ""
            };
            a.embeddedPlayerMode = c.Ea;
            g.qC("embedsAdEvent", a)
        };
    var Yrb = Object.prototype.hasOwnProperty;
    Vrb.prototype = Object.create(null);
    var Itb = asb();
    var n5 = null;
    var isb = "undefined" !== typeof Node && Node.prototype.getRootNode || function() {
        for (var a = this, b = a; a;) b = a, a = a.parentNode;
        return b
    };
    var g5 = null,
        i5 = null,
        e5 = null,
        k5 = null,
        l5 = [],
        j5 = fsb,
        m5 = [],
        Gtb = function(a) {
            return jsb(function(b, c, d) {
                e5 = i5 = b;
                i5 = null;
                c(d);
                h5(null);
                i5 = e5;
                e5 = e5.parentNode;
                return b
            }, a)
        }(),
        Ftb = function(a) {
            return jsb(function(b, c, d) {
                var e = {
                    nextSibling: b
                };
                i5 = e;
                c(d);
                e5 && h5(b.nextSibling);
                return e === i5 ? null : i5
            }, a)
        }();
    var o5 = [],
        Jtb = 0;
    var $5 = new Vrb;
    var r5 = {
        attributes: asb(),
        Sz: function(a, b) {
            throw b;
        },
        m7: !0,
        jea: g.Zib,
        hea: g.$ib
    };
    var p5 = [],
        osb = Symbol("comp_stack_added");
    var G5 = Symbol("IS_VNODE");
    t5.prototype.CD = function() {};
    t5.prototype.b7 = function() {};
    t5.prototype.sI = function() {};
    t5.prototype.c7 = function() {};
    var F5 = {
        unb: function() {},
        Ipb: function() {},
        ynb: function() {},
        iW: function() {},
        vnb: function() {},
        b7: function() {},
        CD: function() {},
        sI: function() {},
        c7: function() {}
    };
    var u5 = null;
    var qsb = null,
        x5 = !1,
        zsb = Symbol("SIGNAL"),
        z5 = {
            version: 0,
            TY: 0,
            Yl: !1,
            vk: void 0,
            rB: void 0,
            Nr: void 0,
            CQ: 0,
            bk: void 0,
            Rw: void 0,
            VN: !1,
            HW: !1,
            W_: function() {
                return !1
            },
            X_: function() {},
            IW: function() {},
            Knb: function() {}
        };
    var uub = Symbol("UNSET"),
        vub = Symbol("COMPUTING"),
        wub = Symbol("ERRORED");
    Object.assign({}, z5, {
        value: uub,
        Yl: !0,
        error: null,
        fX: psb,
        W_: function(a) {
            return a.value === uub || a.value === vub
        },
        X_: function(a) {
            if (a.value === vub) throw Error("Detected cycle in computations.");
            var b = a.value;
            a.value = vub;
            var c = ssb(a);
            try {
                var d = a.Inb()
            } catch (e) {
                d = wub, a.error = e
            } finally {
                vsb(a, c)
            }
            b !== uub && b !== wub && d !== wub && a.fX(b, d) ? a.value = b : (a.value = d, a.version++)
        }
    });
    Object.assign({}, z5, {
        fX: psb,
        value: void 0
    });
    var xsb = Object.assign({}, z5, {
        HW: !0,
        VN: !1,
        IW: function(a) {
            null !== a.schedule && a.schedule(a.xB)
        },
        oY: !1,
        gz: ysb
    });
    var Gsb = Bsb(!1);
    var Csb = {};
    var ltb = Bsb(!0);
    var D5 = null;
    g.y(E5, t5);
    E5.prototype.Ix = function(a) {
        var b = this,
            c = D5;
        D5 = this;
        this.D = 0;
        try {
            return s5(function() {
                return A5(ltb, function() {
                    return v5(b.wI, function() {
                        return b.B(a)
                    })
                })
            })
        } finally {
            D5 = c
        }
    };
    var Lsb = [];
    (function() {
        var a = n5;
        n5 = function(b) {
            null == a || a(b);
            Msb(b)
        }
    })();
    var I5 = Nsb;
    var S5;
    var Htb = Symbol("ATTR_TAG_VALUE");
    var T5 = Symbol("reactiveData");
    var Rsb = new Set,
        R5 = new Set;
    var gtb = new Set("allowfullscreen async autofocus autoplay checked controls default defer disabled formnovalidate hidden ismap itemscope jsshadow jsslot loop multiple muted novalidate open playsinline readonly required reversed scoped seamless selected spellcheck sortable typemustmatch".split(" "));
    var ctb = {
            align: 1,
            alt: 1,
            "aria-activedescendant": 10,
            "aria-atomic": 1,
            "aria-autocomplete": 1,
            "aria-busy": 1,
            "aria-checked": 1,
            "aria-controls": 10,
            "aria-current": 1,
            "aria-disabled": 1,
            "aria-dropeffect": 1,
            "aria-expanded": 1,
            "aria-haspopup": 1,
            "aria-hidden": 1,
            "aria-invalid": 1,
            "aria-label": 1,
            "aria-labelledby": 10,
            "aria-level": 1,
            "aria-live": 1,
            "aria-multiline": 1,
            "aria-multiselectable": 1,
            "aria-orientation": 1,
            "aria-owns": 10,
            "aria-posinset": 1,
            "aria-pressed": 1,
            "aria-readonly": 1,
            "aria-relevant": 1,
            "aria-required": 1,
            "aria-selected": 1,
            "aria-setsize": 1,
            "aria-sort": 1,
            "aria-valuemax": 1,
            "aria-valuemin": 1,
            "aria-valuenow": 1,
            "aria-valuetext": 1,
            async: 8,
            autocapitalize: 1,
            autocomplete: 1,
            autocorrect: 1,
            autofocus: 1,
            autoplay: 1,
            bgcolor: 1,
            border: 1,
            cellpadding: 1,
            cellspacing: 1,
            checked: 1,
            cite: 3,
            "class": 1,
            color: 1,
            cols: 1,
            colspan: 1,
            contenteditable: 1,
            controls: 1,
            datetime: 1,
            dir: 8,
            disabled: 1,
            download: 1,
            draggable: 1,
            enctype: 1,
            face: 1,
            "for": 10,
            formenctype: 1,
            frameborder: 1,
            height: 1,
            hidden: 1,
            href: 4,
            hreflang: 1,
            id: 10,
            ismap: 1,
            itemid: 1,
            itemprop: 1,
            itemref: 1,
            itemscope: 1,
            itemtype: 1,
            label: 1,
            lang: 1,
            list: 10,
            loading: 8,
            loop: 1,
            max: 1,
            maxlength: 1,
            media: 1,
            min: 1,
            minlength: 1,
            multiple: 1,
            muted: 1,
            name: 10,
            nonce: 1,
            open: 1,
            placeholder: 1,
            poster: 3,
            preload: 1,
            rel: 1,
            required: 1,
            reversed: 1,
            role: 1,
            rows: 1,
            rowspan: 1,
            selected: 1,
            shape: 1,
            size: 1,
            sizes: 1,
            slot: 1,
            span: 1,
            spellcheck: 1,
            src: 4,
            srcset: 12,
            start: 1,
            step: 1,
            style: 5,
            summary: 1,
            tabindex: 1,
            target: 8,
            title: 1,
            translate: 1,
            type: 1,
            valign: 1,
            value: 1,
            width: 1,
            wrap: 1
        },
        btb = {
            a: {
                href: [{
                    qd: 3
                }]
            },
            area: {
                href: [{
                    qd: 3
                }]
            },
            audio: {
                src: [{
                    qd: 3
                }]
            },
            button: {
                formaction: [{
                    qd: 3
                }],
                formmethod: [{
                    qd: 1
                }]
            },
            form: {
                action: [{
                    qd: 3
                }],
                method: [{
                    qd: 1
                }]
            },
            iframe: {
                srcdoc: [{
                    qd: 2
                }]
            },
            img: {
                src: [{
                    qd: 3
                }],
                srcset: [{
                    qd: 11
                }]
            },
            input: {
                accept: [{
                    qd: 1
                }],
                formaction: [{
                    qd: 3
                }],
                formmethod: [{
                    qd: 1
                }],
                pattern: [{
                    qd: 1
                }],
                readonly: [{
                    qd: 1
                }],
                src: [{
                    qd: 3
                }]
            },
            link: {
                href: [{
                    qd: 3,
                    oi: "rel",
                    Fi: "alternate"
                }, {
                    qd: 3,
                    oi: "rel",
                    Fi: "author"
                }, {
                    qd: 3,
                    oi: "rel",
                    Fi: "bookmark"
                }, {
                    qd: 3,
                    oi: "rel",
                    Fi: "canonical"
                }, {
                    qd: 3,
                    oi: "rel",
                    Fi: "cite"
                }, {
                    qd: 3,
                    oi: "rel",
                    Fi: "help"
                }, {
                    qd: 3,
                    oi: "rel",
                    Fi: "icon"
                }, {
                    qd: 3,
                    oi: "rel",
                    Fi: "license"
                }, {
                    qd: 3,
                    oi: "rel",
                    Fi: "next"
                }, {
                    qd: 3,
                    oi: "rel",
                    Fi: "prefetch"
                }, {
                    qd: 3,
                    oi: "rel",
                    Fi: "dns-prefetch"
                }, {
                    qd: 3,
                    oi: "rel",
                    Fi: "prerender"
                }, {
                    qd: 3,
                    oi: "rel",
                    Fi: "preconnect"
                }, {
                    qd: 3,
                    oi: "rel",
                    Fi: "preload"
                }, {
                    qd: 3,
                    oi: "rel",
                    Fi: "prev"
                }, {
                    qd: 3,
                    oi: "rel",
                    Fi: "search"
                }, {
                    qd: 3,
                    oi: "rel",
                    Fi: "subresource"
                }]
            },
            script: {
                defer: [{
                    qd: 1
                }]
            },
            source: {
                src: [{
                    qd: 3
                }],
                srcset: [{
                    qd: 11
                }]
            },
            textarea: {
                readonly: [{
                    qd: 1
                }]
            },
            video: {
                src: [{
                    qd: 3
                }]
            }
        };
    var xub = /^(?!javascript:)(?:[a-z0-9+.-]+:|[^&:\/?#]*(?:[\/?#]|$))/i,
        i6 = {},
        etb = (i6[1] = {
            Sq: null,
            Qt: null,
            xs: null
        }, i6[2] = {
            Sq: function() {
                return g.ee.toString()
            },
            Qt: function(a) {
                return a instanceof g.me
            },
            xs: function(a) {
                return g.ne(a)
            }
        }, i6[3] = {
            Sq: function(a, b, c) {
                return xub.test(c) ? c : g.ee.toString()
            },
            Qt: function(a) {
                return a instanceof g.Zd
            },
            xs: function(a) {
                return g.$d(a)
            }
        }, i6[4] = {
            Sq: function() {
                return g.ee.toString()
            },
            Qt: function(a) {
                return a instanceof g.Ud
            },
            xs: function(a) {
                return g.Vd(a)
            }
        }, i6[5] = {
            Sq: null,
            Qt: function(a) {
                return a instanceof g.ke
            },
            xs: function(a) {
                return a.toString()
            }
        }, i6[7] = {
            Sq: null,
            Qt: null,
            xs: null
        }, i6[8] = {
            Sq: null,
            Qt: null,
            xs: null
        }, i6[10] = {
            Sq: null,
            Qt: null,
            xs: null
        }, i6);
    var yub = asb(),
        itb = yub.__default,
        jtb = yub.style,
        htb = ["focusin", "focusout"];
    var qtb = mtb;
    S5 = rtb;
    (function(a) {
        var b = {},
            c;
        for (c in a) b = {
            P_: void 0,
            EZ: void 0
        }, b.P_ = F5[c], b.EZ = a[c], F5[c] = function(d) {
            return function() {
                var e = g.Ia.apply(0, arguments);
                d.P_.apply(null, g.qa(e));
                d.EZ.apply(null, g.qa(e))
            }
        }(b)
    })({
        iW: function(a) {
            v5(a.wI, function() {
                var b;
                (null == (b = a.Ty) ? 0 : b.length) && Atb(a.Ty)
            })
        },
        CD: function(a) {
            v5(a.wI, function() {
                var b;
                (null == (b = a.Ty) ? 0 : b.length) && Atb(a.Ty)
            })
        },
        sI: function(a) {
            var b;
            (null == (b = a.Xz) ? 0 : b.length) && a.Xz.forEach(ztb)
        }
    });
    S5 = rtb;
    var zub = {},
        Aub = (zub.__default = function() {
            return V5
        }, zub.style = function() {
            return V5
        }, zub),
        j6;
    for (j6 in Aub) r5.attributes[j6] = Aub[j6](r5.attributes[j6]);
    var Stb = [],
        Ttb = !1;
    g.y($tb, g.W);
    g.k = $tb.prototype;
    g.k.hide = function() {
        this.N = !0;
        g.W.prototype.hide.call(this);
        aub(this, !1)
    };
    g.k.show = function() {
        this.N = !1;
        g.W.prototype.show.call(this);
        aub(this, !0)
    };
    g.k.isHidden = function() {
        return this.N
    };
    g.k.Q3 = function() {
        this.scrollTo(this.C - this.containerWidth)
    };
    g.k.R3 = function() {
        this.scrollTo(this.C + this.containerWidth)
    };
    g.k.resize = function(a, b) {
        var c = this.api.U(),
            d = 16 / 9,
            e = 650 <= a.width,
            f = 480 > a.width || 290 > a.height,
            h = Math.min(this.suggestionData.length, this.j.length);
        if (150 >= Math.min(a.width, a.height) || 0 === h || !c.xd) this.hide();
        else {
            var l;
            if (e) {
                var m = l = 28;
                this.B = 16
            } else this.B = m = l = 8;
            if (f) {
                var n = 6;
                e = 14;
                var p = 12;
                f = 24;
                c = 12
            } else n = 8, e = 18, p = 16, f = 36, c = 16;
            a = a.width - (48 + l + m);
            l = Math.ceil(a / 150);
            l = Math.min(3, l);
            m = a / l - this.B;
            var q = Math.floor(m / d);
            b && q + 100 > b && 50 < m && (q = Math.max(b, 50 / d), l = Math.ceil(a / (d * (q - 100) + this.B)), m = a / l - this.B,
                q = Math.floor(m / d));
            50 > m || g.TT(this.api) ? this.hide() : this.show();
            for (b = 0; b < h; b++) {
                d = this.j[b];
                var r = d.Ga("ytp-suggestion-image");
                r.style.width = m + "px";
                r.style.height = q + "px";
                d.Ga("ytp-suggestion-title").style.width = m + "px";
                d.Ga("ytp-suggestion-author").style.width = m + "px";
                d = d.Ga("ytp-suggestion-duration");
                d.style.display = d && 100 > m ? "none" : ""
            }
            h = e + n + p + 4;
            this.K = h + c + (q - f) / 2;
            this.suggestions.element.style.height = q + h + "px";
            this.D = m;
            this.containerWidth = a;
            this.columns = l;
            this.C = 0;
            this.suggestions.element.scrollLeft = -0;
            bub(this)
        }
    };
    g.k.onVideoDataChange = function() {
        var a = this.api.getVideoData(),
            b = this.api.U();
        this.Y = a.Hf ? !1 : b.D;
        a.suggestions ? this.suggestionData = g.Nt(a.suggestions, function(c) {
            return c && !c.playlistId
        }) : this.suggestionData.length = 0;
        cub(this);
        a.Hf ? this.title.update({
            title: g.rJ("More videos from $DNI_RELATED_CHANNEL", {
                DNI_RELATED_CHANNEL: a.author
            })
        }) : this.title.update({
            title: "More videos on YouTube"
        })
    };
    g.k.scrollTo = function(a) {
        a = g.ye(a, this.containerWidth - this.suggestionData.length * (this.D + this.B), 0);
        this.qa.start(this.C, a, 1E3);
        this.C = a;
        bub(this);
        aub(this, !0)
    };
    g.y(a6, g.RV);
    a6.prototype.show = function() {
        g.RV.prototype.show.call(this);
        eub(this, this.api.ob().getPlayerSize())
    };
    a6.prototype.resize = function(a) {
        g.RV.prototype.resize.call(this, a);
        this.j && (eub(this, a), g.Dv(this.element, "related-on-error-overlay-visible", !this.j.isHidden()))
    };
    a6.prototype.B = function(a) {
        g.RV.prototype.B.call(this, a);
        var b = this.api.getVideoData();
        if (b.UC || b.playerErrorMessageRenderer)(a = b.UC) ? hub(this, a) : b.playerErrorMessageRenderer && hub(this, b.playerErrorMessageRenderer);
        else {
            var c;
            a.qn && (b.Jy ? fub(b.Jy) ? c = g.mF(b.Jy) : c = g.SV(g.lF(b.Jy)) : c = g.SV(a.qn), this.Jd(c, "subreason"))
        }
    };
    g.y(iub, g.W);
    g.k = iub.prototype;
    g.k.onVideoDataChange = function() {
        var a = this.api.getVideoData(),
            b = Trb(),
            c = 96714;
        g.yT(a) && (b = Urb(), c = 216165);
        this.updateValue("logoSvg", b);
        this.api.hasVe(this.element) && this.api.destroyVe(this.element);
        this.api.createClientVe(this.element, this, c)
    };
    g.k.hk = function() {
        this.api.getPlayerStateObject().isCued() || (this.hide(), this.api.logVisibility(this.element, !1))
    };
    g.k.ZT = function() {
        var a = this.api.getVideoData(),
            b = this.api.U(),
            c = this.api.getVideoData().Hf,
            d = b.Rd,
            e = !b.xd,
            f = this.Qe.Kg();
        b = b.C;
        d || f || c || e || b || this.api.Wc() || !a.videoId ? (this.hide(), this.api.logVisibility(this.element, !1)) : (a = jub(this), this.updateValue("url", a), this.show())
    };
    g.k.onClick = function(a) {
        this.api.L("web_player_log_click_before_generating_ve_conversion_params") && this.api.logClick(this.element);
        var b = jub(this);
        g.oU(b, this.api, a);
        this.api.L("web_player_log_click_before_generating_ve_conversion_params") || this.api.logClick(this.element)
    };
    g.k.show = function() {
        this.api.getPlayerStateObject().isCued() && (g.W.prototype.show.call(this), this.api.hasVe(this.element) && this.api.logVisibility(this.element, !0))
    };
    g.y(b6, g.W);
    b6.prototype.hk = function() {
        var a = this.api.getPlayerStateObject();
        !this.api.Wh() || g.SF(a, 2) && g.QT(this.api) || g.SF(a, 64) ? (this.api.logVisibility(this.j, !1), this.api.logVisibility(this.forwardButton, !1), this.hide()) : (this.show(), this.api.logVisibility(this.j, !0), this.api.logVisibility(this.forwardButton, !0))
    };
    b6.prototype.B = function() {
        this.api.seekBy(-10 * this.api.getPlaybackRate(), void 0, void 0, 83);
        this.api.logClick(this.j)
    };
    b6.prototype.C = function() {
        this.api.seekBy(10 * this.api.getPlaybackRate(), void 0, void 0, 82);
        this.api.logClick(this.forwardButton)
    };
    g.y(c6, g.W);
    c6.prototype.C = function() {
        var a = this.api.getPlayerStateObject();
        this.api.getVideoData().mutedAutoplay && (g.SF(a, 2) && !this.Fb ? (this.show(), this.j || (this.j = new g.PV(this.api), g.N(this, this.j), this.j.Ja(this.D, 0), this.j.show()), a = this.api.getVideoData(), this.updateValue("text", a.CT), g.Dv(this.element, "ytp-muted-autoplay-show-end-panel", !0), this.api.logVisibility(this.element, this.Fb), this.api.zc("onMutedAutoplayEnds")) : this.hide())
    };
    c6.prototype.onClick = function() {
        if (!this.B) {
            this.j && (this.j.va(), this.j = null);
            g.Dv(this.api.getRootNode(), "ytp-muted-autoplay", !1);
            var a = this.api.getVideoData(),
                b = this.api.getCurrentTime();
            Srb(a);
            this.api.loadVideoById(a.videoId, b);
            this.api.DA();
            this.api.logClick(this.element);
            this.hide();
            this.B = !0
        }
    };
    c6.prototype.onMutedAutoplayStarts = function() {
        this.B = !1;
        this.j && (this.j.va(), this.j = null)
    };
    g.y(d6, g.W);
    g.k = d6.prototype;
    g.k.onStateChange = function(a) {
        this.Dc(a.state)
    };
    g.k.Dc = function(a) {
        this.state !== a && (this.state = a);
        kub(this)
    };
    g.k.onVideoDataChange = function() {
        var a = this.api.U();
        a.C && g.zv(this.element, "ytp-no-hover");
        var b = this.api.getVideoData();
        b.videoId && !a.C ? (a = this.api.getVideoUrl(!0, !1, !1, !0), this.updateValue("url", a), this.j || (this.j = this.listen("click", this.onClick))) : this.j && (this.updateValue("url", null), this.Nc(this.j), this.j = null);
        a = Trb();
        var c = 76758;
        g.yT(b) && (a = Urb(), c = 216164);
        this.updateValue("logoSvg", a);
        this.api.hasVe(this.element) && this.api.destroyVe(this.element);
        this.api.createClientVe(this.element, this,
            c);
        kub(this)
    };
    g.k.onClick = function(a) {
        this.api.L("web_player_log_click_before_generating_ve_conversion_params") && this.api.logClick(this.element);
        var b = this.api.getVideoUrl(!g.cG(a), !1, !0, !0);
        if (this.api.L("web_player_log_click_before_generating_ve_conversion_params")) {
            var c = {};
            g.ET(this.api, "addEmbedsConversionTrackingParams", [c]);
            b = g.Sn(b, g.YO(c, "emb_yt_watermark"))
        }
        g.oU(b, this.api, a);
        this.api.L("web_player_log_click_before_generating_ve_conversion_params") || this.api.logClick(this.element)
    };
    g.k.dc = function(a) {
        if ((a = 480 > a.width) && !this.B || !a && this.B) {
            var b = new g.W(Trb()),
                c = this.Ga("ytp-watermark");
            g.Dv(c, "ytp-watermark-small", a);
            g.Df(c);
            b.Ja(c);
            this.B = a
        }
    };
    g.y(nub, g.W);
    g.k = nub.prototype;
    g.k.qM = function() {
        var a = this.api.getPlayerStateObject();
        !this.api.getVideoData().mutedAutoplay || g.SF(a, 2) ? this.hide() : this.Fb || (g.W.prototype.show.call(this), this.api.logVisibility(this.element, this.Fb))
    };
    g.k.X8 = function() {
        this.j && this.j.hide()
    };
    g.k.onAutoplayBlocked = function() {
        this.hide();
        Srb(this.api.getVideoData())
    };
    g.k.onClick = function() {
        if (!this.B) {
            g.Dv(this.api.getRootNode(), "ytp-muted-autoplay", !1);
            var a = this.api.getVideoData(),
                b = this.api.getCurrentTime();
            Srb(a);
            this.api.loadVideoById(a.videoId, b);
            this.api.DA();
            this.api.logClick(this.element);
            this.api.zc("onMutedAutoplayEnds");
            this.B = !0
        }
    };
    g.k.onMutedAutoplayEnds = function() {
        this.watermark && (this.watermark.va(), this.watermark = null)
    };
    g.y(e6, g.W);
    e6.prototype.hide = function() {
        g.Bv(this.api.getRootNode(), "ytp-expand-pause-overlay");
        g.W.prototype.hide.call(this)
    };
    e6.prototype.G = function() {
        this.B = !0;
        g.Bv(this.api.getRootNode(), "ytp-expand-pause-overlay");
        this.api.Wc() && this.api.logVisibility(this.element, !1);
        this.expandButton.focus()
    };
    e6.prototype.K = function() {
        this.B = !1;
        g.zv(this.api.getRootNode(), "ytp-expand-pause-overlay");
        this.api.Wc() && this.api.logVisibility(this.element, !0);
        this.focus()
    };
    e6.prototype.Ta = function() {
        var a = this.api.getPlayerStateObject();
        g.SF(a, 1) || g.SF(a, 16) || g.SF(a, 32) || (!g.SF(a, 4) || g.SF(a, 2) || g.SF(a, 1024) ? (this.B || this.api.logVisibility(this.element, !1), this.D.hide()) : 0 < this.j.suggestionData.length && (this.B || (g.zv(this.api.getRootNode(), "ytp-expand-pause-overlay"), g.g2(this.j), this.j.show(), this.api.logVisibility(this.element, !0)), this.D.show()))
    };
    g.y(f6, g.W);
    f6.prototype.show = function() {
        g.W.prototype.show.call(this);
        this.api.logVisibility(this.element, !0)
    };
    f6.prototype.va = function() {
        g6(this);
        g.W.prototype.va.call(this)
    };
    g.y(rub, g.uV);
    g.k = rub.prototype;
    g.k.Gm = function() {
        return !1
    };
    g.k.create = function() {
        var a = this.J.U(),
            b = g.KT(this.J),
            c, d = null == (c = this.J.getVideoData()) ? void 0 : c.clientPlaybackNonce;
        d && g.gH({
            clientPlaybackNonce: d
        });
        a.bb && tub(this);
        this.Z = new nub(this.J);
        g.N(this, this.Z);
        g.WT(this.J, this.Z.element, 4);
        this.ra = new c6(this.J);
        g.N(this, this.ra);
        g.WT(this.J, this.ra.element, 4);
        a.Rd && (this.watermark = new d6(this.J), g.N(this, this.watermark), g.WT(this.J, this.watermark.element, 8));
        b && (this.K = new iub(this.J, b), g.N(this, this.K), g.WT(this.J, this.K.element, 8), g.IT(this.J.app) &&
            (this.onMutedAutoplayStarts(), this.K.hide()));
        a.B && (this.qa = new b6(this.J), g.N(this, this.qa), g.WT(this.J, this.qa.element, 4));
        this.j.T(this.J, "appresize", this.dc);
        this.j.T(this.J, "presentingplayerstatechange", this.hk);
        this.j.T(this.J, "videodatachange", this.onVideoDataChange);
        this.j.T(this.J, "videoplayerreset", this.onReset);
        this.j.T(this.J, "onMutedAutoplayStarts", this.onMutedAutoplayStarts);
        this.j.T(this.J, "onAdStart", this.onAdStart);
        this.j.T(this.J, "onAdComplete", this.onAdComplete);
        this.j.T(this.J,
            "onAdSkip", this.onAdSkip);
        this.j.T(this.J, "onAdStateChange", this.onAdStateChange);
        if (this.N = g.FB(g.LR(a))) this.countdownTimer = new f6(this.J), g.N(this, this.countdownTimer), g.WT(this.J, this.countdownTimer.element, 4), this.countdownTimer.hide(), this.j.T(this.J, g.lJ("embeds"), this.onCueRangeEnter), this.j.T(this.J, g.mJ("embeds"), this.onCueRangeExit);
        this.Cc(this.J.getPlayerStateObject());
        this.player.zg("embed");
        var e, f;
        (null == (e = this.J.U().getWebPlayerContextConfig()) ? 0 : null == (f = e.embedsHostFlags) ? 0 : f.allowOverridingVisitorDataPlayerVars) &&
        (a = g.HA("IDENTITY_MEMENTO")) && this.J.Cm("onMementoChange", a)
    };
    g.k.onCueRangeEnter = function(a) {
        "countdown timer" === a.getId() && this.countdownTimer && (this.countdownTimer.show(), pub(this.countdownTimer))
    };
    g.k.onCueRangeExit = function(a) {
        "countdown timer" === a.getId() && this.countdownTimer && (g6(this.countdownTimer), this.countdownTimer.hide())
    };
    g.k.dc = function() {
        var a = this.J.ob().getPlayerSize();
        this.pg && this.pg.resize(a)
    };
    g.k.onReset = function() {
        qub(this)
    };
    g.k.hk = function(a) {
        this.Cc(a.state)
    };
    g.k.Cc = function(a) {
        g.SF(a, 128) ? (this.pg || (this.pg = new a6(this.J), g.N(this, this.pg), g.WT(this.J, this.pg.element, 4)), this.pg.B(a.Ig), this.pg.show(), g.zv(this.J.getRootNode(), "ytp-embed-error")) : this.pg && (this.pg.dispose(), this.pg = null, g.Bv(this.J.getRootNode(), "ytp-embed-error"));
        if (this.countdownTimer && this.countdownTimer.j)
            if (g.SF(a, 64)) this.countdownTimer.hide(), g6(this.countdownTimer);
            else if (a.isPaused()) {
            var b = this.countdownTimer;
            b.B || (b.B = !0, b.G = (0, g.EC)())
        } else a.isPlaying() && this.countdownTimer.B &&
            (b = this.countdownTimer, b.B && (b.D += (0, g.EC)() - b.G, b.B = !1, oub(b)));
        sub(this, a)
    };
    g.k.onMutedAutoplayStarts = function() {
        this.J.getVideoData().mutedAutoplay && this.Z && g.Dv(this.J.getRootNode(), "ytp-muted-autoplay", !0)
    };
    g.k.onVideoDataChange = function(a, b) {
        var c = this.YE !== b.videoId;
        a = !c && "dataloaded" === a;
        var d = {
            isShortsModeEnabled: !!this.J.Wc()
        };
        g.qC("embedsVideoDataDidChange", {
            clientPlaybackNonce: b.clientPlaybackNonce,
            isReload: a,
            runtimeEnabledFeatures: d
        });
        c && (this.YE = b.videoId, this.countdownTimer && (this.countdownTimer.show(), this.countdownTimer.hide()), this.N && (this.J.qf("embeds"), b.isAd() || 5 > b.limitedPlaybackDurationInSeconds || g.TT(this.J) || (b = Math.max(1E3 * (b.startSeconds + b.limitedPlaybackDurationInSeconds - 5), 0),
            b = new g.kJ(b, b + 5E3, {
                id: "countdown timer",
                namespace: "embeds"
            }), this.J.jf([b]))), this.J.U().bb && (qub(this), tub(this)));
        this.J.U().C && this.C && this.C.detach()
    };
    g.k.onAdStart = function() {
        h6(this, "EMBEDS_AD_EVENT_TYPE_AD_STARTED")
    };
    g.k.onAdComplete = function() {
        h6(this, "EMBEDS_AD_EVENT_TYPE_AD_COMPLETED")
    };
    g.k.onAdSkip = function() {
        h6(this, "EMBEDS_AD_EVENT_TYPE_AD_SKIPPED")
    };
    g.k.onAdStateChange = function(a) {
        2 === a && h6(this, "EMBEDS_AD_EVENT_TYPE_AD_PAUSED")
    };
    g.tV("embed", rub);
})(_yt_player);